# 🏗️ Arquitetura do Sistema - Estetica Pro

## 📊 Diagrama da Infraestrutura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              VPS INTEGRATOR                                  │
│                         Ubuntu 22.04 LTS                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         DOCKER NETWORK                              │   │
│  │                    estetica-network (bridge)                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│  ┌─────────────────┐  ┌──────────┴──────────┐  ┌─────────────────┐        │
│  │   NGINX         │  │    BACKEND          │  │    FRONTEND     │        │
│  │   (Reverse      │  │   Node.js +         │  │   React +       │        │
│  │    Proxy)       │  │   Express           │  │   TypeScript    │        │
│  │                 │  │                     │  │                 │        │
│  │  Portas:        │  │  Porta: 3000        │  │  Porta: 80      │        │
│  │  - 80 (HTTP)    │  │                     │  │                 │        │
│  │  - 443 (HTTPS)  │  │  Responsabilidades: │  │  Build estático │        │
│  │                 │  │  - API REST         │  │  servido pelo   │        │
│  │  Responsabilidades:  - Autenticação JWT │  │  nginx interno  │        │
│  │  - SSL/TLS      │  │  - Regras de negócio│  │                 │        │
│  │  - Rate Limit   │  │  - Integrações      │  │                 │        │
│  │  - Load Balance │  │  - WebSockets       │  │                 │        │
│  └────────┬────────┘  └──────────┬──────────┘  └─────────────────┘        │
│           │                      │                                         │
│           └──────────────────────┘                                         │
│                      │                                                     │
│  ┌───────────────────┴────────────────────────────────────────────────┐   │
│  │                         DATABASE                                    │   │
│  │                    PostgreSQL 15                                    │   │
│  │                                                                     │   │
│  │  Porta: 5432 (interna apenas)                                       │   │
│  │                                                                     │   │
│  │  Volumes:                                                           │   │
│  │  - postgres_data:/var/lib/postgresql/data                          │   │
│  │  - ./backups:/backups                                               │   │
│  │                                                                     │   │
│  │  Responsabilidades:                                                 │   │
│  │  - Dados da aplicação                                               │   │
│  │  - Backup automático                                                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      ARMAZENAMENTO                                  │   │
│  │                                                                     │   │
│  │  Volumes Docker:                                                    │   │
│  │  - postgres_data    → Dados do PostgreSQL                          │   │
│  │  - uploads_data     → Fotos antes/depois, documentos               │   │
│  │                                                                     │   │
│  │  Host:                                                              │   │
│  │  - /home/estetica/backups  → Backups automáticos                   │   │
│  │  - /home/estetica/logs     → Logs da aplicação                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTPS (443)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              USUÁRIOS                                       │
│                                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │   Desktop    │  │   Tablet     │  │   Mobile     │  │   Admin      │   │
│  │   (Web)      │  │   (PWA)      │  │   (PWA)      │  │   (Web)      │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Fluxo de Dados

### 1. Requisição HTTP/HTTPS
```
Usuário → DNS → VPS Integrator → Nginx → Frontend (React)
                                    ↓
                              API Request
                                    ↓
                              Backend (Node.js)
                                    ↓
                              PostgreSQL
```

### 2. Autenticação
```
Login Request → Backend → Validação → JWT Token → Cookie/Header
                ↓
         PostgreSQL (Users)
```

### 3. Agendamento
```
Criar Agendamento → Backend → Validação → Database
                          ↓
                    Notificações (WhatsApp/Email)
```

---

## 🛡️ Camadas de Segurança

```
┌─────────────────────────────────────────────────────────────┐
│  1. PERIMETER (Firewall UFW)                                │
│     - Portas 22, 80, 443 apenas                            │
│     - Rate limiting por IP                                  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  2. APLICAÇÃO (Nginx)                                       │
│     - SSL/TLS (Let's Encrypt)                              │
│     - Headers de segurança                                  │
│     - Rate limiting por endpoint                            │
│     - WAF básico                                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  3. API (Node.js/Express)                                   │
│     - Autenticação JWT                                      │
│     - Validação de inputs                                   │
│     - CORS configurado                                      │
│     - Helmet.js                                             │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  4. DADOS (PostgreSQL)                                      │
│     - Isolamento em rede Docker                            │
│     - Credenciais seguras                                   │
│     - Backup criptografado                                  │
│     - Acesso apenas via backend                            │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 Componentes Docker

### Container: nginx
```yaml
Imagem: nginx:alpine
Portas: 80, 443
Volumes:
  - ./nginx/conf.d:/etc/nginx/conf.d
  - ./certbot/conf:/etc/letsencrypt
  - ./certbot/www:/var/www/certbot
Dependências: backend, frontend
```

### Container: backend
```yaml
Imagem: node:18-alpine (build)
Porta: 3000
Volumes:
  - ./backend/uploads:/app/uploads
  - ./backend/logs:/app/logs
Variáveis: .env
Dependências: db
```

### Container: frontend
```yaml
Imagem: nginx:alpine
Porta: 80
Volumes:
  - ./frontend/dist:/usr/share/nginx/html
  - ./nginx/frontend.conf:/etc/nginx/conf.d/default.conf
Dependências: Nenhuma
```

### Container: db
```yaml
Imagem: postgres:15-alpine
Porta: 5432 (interna)
Volumes:
  - postgres_data:/var/lib/postgresql/data
  - ./backups:/backups
Variáveis:
  POSTGRES_USER: estetica_user
  POSTGRES_PASSWORD: ${DB_PASSWORD}
  POSTGRES_DB: estetica_db
```

---

## 🔄 Backup e Recuperação

### Estratégia de Backup
```
┌─────────────────────────────────────────────────────────────┐
│  BACKUP AUTOMÁTICO (Diário às 2h)                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Database Dump                                           │
│     pg_dump → gzip → /home/estetica/backups/               │
│                                                             │
│  2. Arquivos (Uploads)                                      │
│     tar.gz → /home/estetica/backups/                       │
│                                                             │
│  3. Configurações                                           │
│     .env, nginx.conf → backup separado                     │
│                                                             │
│  4. Retenção: 30 dias                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Recuperação de Desastres
```bash
# 1. Parar aplicação
docker compose -f docker-compose.prod.yml down

# 2. Restaurar banco
gunzip < backup_20250115.sql.gz | docker exec -i estetica-db psql -U estetica_user -d estetica_db

# 3. Restaurar arquivos
tar -xzf uploads_20250115.tar.gz -C /home/estetica/apps/estetica-pro/backend

# 4. Reiniciar
docker compose -f docker-compose.prod.yml up -d
```

---

## 📊 Escalabilidade

### Vertical (Upgrade de VPS)
```
Plano Atual: 2 vCPU, 4GB RAM
     ↓
Upgrade: 4 vCPU, 8GB RAM
     ↓
Upgrade: 8 vCPU, 16GB RAM
```

### Horizontal (Futuro)
```
Load Balancer (Nginx)
       ↓
┌──────┴──────┐
│             │
Backend 1   Backend 2
│             │
└──────┬──────┘
       ↓
   PostgreSQL
   (Primary-Replica)
```

---

## 🔍 Monitoramento

### Métricas Coletadas
```
┌─────────────────────────────────────────────────────────────┐
│  SISTEMA                                                    │
│  - CPU Usage                                                │
│  - Memory Usage                                             │
│  - Disk I/O                                                 │
│  - Network Traffic                                          │
├─────────────────────────────────────────────────────────────┤
│  APLICAÇÃO                                                  │
│  - Request Rate                                             │
│  - Response Time                                            │
│  - Error Rate                                               │
│  - Active Users                                             │
├─────────────────────────────────────────────────────────────┤
│  BANCO DE DADOS                                             │
│  - Query Performance                                        │
│  - Connection Pool                                          │
│  - Replication Lag                                          │
│  - Disk Usage                                               │
└─────────────────────────────────────────────────────────────┘
```

### Ferramentas
- **Netdata**: Monitoramento em tempo real
- **Portainer**: Gerenciamento Docker
- **Logs**: Centralizados em `/home/estetica/logs/`

---

## 🌐 Configuração DNS Recomendada

```
Tipo    Nome                Valor                           TTL
─────────────────────────────────────────────────────────────────
A       @                   IP_DA_VPS                       3600
A       www                 IP_DA_VPS                       3600
A       app                 IP_DA_VPS                       3600
CNAME   api                 app.seudominio.com.br           3600
TXT     @                   "v=spf1 include:_spf.google.com ~all" 3600
```

---

## 📝 Checklist de Arquitetura

- [ ] Containers isolados por serviço
- [ ] Rede Docker dedicada
- [ ] Volumes persistentes configurados
- [ ] SSL/TLS implementado
- [ ] Backup automático configurado
- [ ] Monitoramento ativo
- [ ] Logs centralizados
- [ ] Rate limiting implementado
- [ ] Firewall configurado
- [ ] Fail2Ban ativo
- [ ] Atualizações automáticas de segurança
- [ ] Documentação atualizada

---

**Arquitetura projetada para alta disponibilidade, segurança e escalabilidade na VPS Integrator.**
