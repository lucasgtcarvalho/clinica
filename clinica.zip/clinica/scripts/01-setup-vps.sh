#!/bin/bash
# =============================================================================
# Clinic SaaS - Preparação da VPS (Ubuntu 20.04/22.04)
# Execute como root ou com sudo. Uso: sudo ./01-setup-vps.sh
# =============================================================================

set -e

echo "=============================================="
echo "  Clinic SaaS - Setup VPS (Node, PostgreSQL, Nginx, PM2)"
echo "=============================================="

# Atualizar sistema
echo "[1/6] Atualizando sistema..."
apt update && apt upgrade -y

# Ferramentas básicas
echo "[2/6] Instalando ferramentas (curl, wget, git, build-essential)..."
apt install -y curl wget git build-essential

# Node.js 18
echo "[3/6] Instalando Node.js 18 LTS..."
if ! command -v node &> /dev/null || [[ $(node -v | cut -d. -f1 | tr -d 'v') -lt 18 ]]; then
  curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
  apt install -y nodejs
fi
echo "  Node: $(node -v) | npm: $(npm -v)"

# PostgreSQL
echo "[4/6] Instalando PostgreSQL..."
apt install -y postgresql postgresql-contrib
systemctl start postgresql
systemctl enable postgresql
echo "  PostgreSQL: $(psql --version 2>/dev/null || echo 'instalado')"

# Nginx
echo "[5/6] Instalando Nginx..."
apt install -y nginx
systemctl start nginx
systemctl enable nginx
echo "  Nginx instalado e ativo."

# PM2 global
echo "[6/6] Instalando PM2..."
npm install -g pm2
echo "  PM2: $(pm2 -v)"

echo ""
echo "=============================================="
echo "  Setup VPS concluído."
echo "  Próximo passo: executar 02-setup-database.sh (ajustar DB_PASSWORD antes)"
echo "=============================================="
