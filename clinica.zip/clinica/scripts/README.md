# Scripts de instalação – Clinic SaaS (VPS Integrator Host)

Scripts para instalação **do zero** na VPS Linux Core da Integrator Host. Use em conjunto com o guia: [INSTALACAO_VPS_INTEGRATOR_CORE.md](../docs/INSTALACAO_VPS_INTEGRATOR_CORE.md).

## Ordem de execução

| Ordem | Script | Onde executar | Descrição |
|-------|--------|----------------|-----------|
| 1 | `01-setup-vps.sh` | Na VPS (root/sudo) | Atualiza sistema, instala Node 18, PostgreSQL, Nginx, PM2 |
| 2 | `02-setup-database.sh` | Na VPS (root/sudo) | Cria banco `clinic_saas` e usuário `clinic_user` |
| 3 | `03-deploy-backend.sh` | Na VPS, na raiz do projeto ou na pasta backend | Instala deps, Prisma, build e sobe backend com PM2 |
| - | `04-nginx-clinic.conf` | Template | Copiar para `/etc/nginx/sites-available/clinic` e ajustar caminhos |

## Uso rápido

### 1. Preparar a VPS (uma vez)

```bash
# Conectar na VPS
ssh root@SEU_IP

# Enviar scripts (no seu PC):
# scp -r scripts root@SEU_IP:/root/

# Na VPS:
chmod +x /root/scripts/*.sh
sudo /root/scripts/01-setup-vps.sh
```

### 2. Criar o banco

```bash
# Definir senha do banco (obrigatório)
export DB_PASSWORD="SuaSenhaForte123!"

sudo /root/scripts/02-setup-database.sh
```

Anote a `DATABASE_URL` para o `.env` do backend.

### 3. Enviar o projeto e fazer deploy do backend

No seu PC (enviar código):

```bash
scp -r backend frontend scripts root@SEU_IP:/root/clinica/
```

Na VPS:

```bash
cd /root/clinica/backend
nano .env   # Colocar DATABASE_URL, JWT_SECRET, FRONTEND_URL, NODE_ENV=production
cd /root/clinica
./scripts/03-deploy-backend.sh
```

### 4. Nginx

Editar `04-nginx-clinic.conf`: ajustar `root` (caminho do frontend) e `server_name` (domínio ou `_` para IP). Depois:

```bash
sudo cp /root/clinica/scripts/04-nginx-clinic.conf /etc/nginx/sites-available/clinic
sudo ln -sf /etc/nginx/sites-available/clinic /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

### 5. Frontend

Build no seu PC com a URL da API correta (ex.: `VITE_API_URL=http://SEU_IP/api`), depois enviar o conteúdo de `dist/` para a pasta que você configurou em `root` no Nginx (ex.: `/root/clinica/frontend-dist/`).

---

## Requisitos

- Ubuntu 20.04 ou 22.04
- Acesso root ou sudo
- Projeto Clinic SaaS (backend + frontend) no servidor

## Documentação completa

Passo a passo detalhado, variáveis de ambiente, SSL e troubleshooting:  
**[docs/INSTALACAO_VPS_INTEGRATOR_CORE.md](../docs/INSTALACAO_VPS_INTEGRATOR_CORE.md)**
