#!/bin/bash
# =============================================================================
# Clinic SaaS - Deploy do backend na VPS
# Execute DENTRO da pasta backend do projeto: cd /caminho/clinica/backend && ../scripts/03-deploy-backend.sh
# Ou: ./scripts/03-deploy-backend.sh (a partir da raiz do projeto)
# Requer: .env já configurado na pasta backend
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKEND_DIR="${BACKEND_DIR:-$PROJECT_ROOT/backend}"

if [ ! -f "$BACKEND_DIR/package.json" ]; then
  echo "Erro: package.json não encontrado em $BACKEND_DIR"
  echo "Execute a partir da raiz do projeto ou defina BACKEND_DIR=..."
  exit 1
fi

cd "$BACKEND_DIR"
echo "=============================================="
echo "  Deploy Backend - $BACKEND_DIR"
echo "=============================================="

if [ ! -f .env ]; then
  echo "AVISO: .env não encontrado. Crie o arquivo .env antes de continuar."
  echo "Copie .env.example e preencha DATABASE_URL, JWT_SECRET, FRONTEND_URL."
  exit 1
fi

echo "[1/5] Instalando dependências..."
npm install

echo "[2/5] Prisma generate..."
npx prisma generate

echo "[3/5] Rodando migrations..."
npx prisma migrate deploy 2>/dev/null || npx prisma db push

echo "[4/5] Build..."
npm run build

echo "[5/5] Reiniciando PM2 (clinic-api)..."
pm2 delete clinic-api 2>/dev/null || true
pm2 start dist/server.js --name clinic-api
pm2 save

echo ""
echo "Backend em execução. Teste: curl http://localhost:3000/health"
pm2 status clinic-api
