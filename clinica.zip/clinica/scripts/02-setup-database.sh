#!/bin/bash
# =============================================================================
# Clinic SaaS - Criação do banco PostgreSQL (clinic_saas + usuário clinic_user)
# Uso:
#   export DB_PASSWORD="sua_senha_segura"
#   sudo ./02-setup-database.sh
# Ou edite DB_PASSWORD abaixo e execute: sudo ./02-setup-database.sh
# =============================================================================

set -e

DB_NAME="clinic_saas"
DB_USER="clinic_user"
# Defina a senha aqui ou via variável de ambiente (export DB_PASSWORD="...")
DB_PASSWORD="${DB_PASSWORD:-MudarSenha123!}"

echo "=============================================="
echo "  Criando banco: $DB_NAME | usuário: $DB_USER"
echo "=============================================="

# Criar banco (ignora erro se já existir)
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname = '$DB_NAME'" | grep -q 1 || \
  sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;"

# Criar ou atualizar usuário
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';" 2>/dev/null || \
  sudo -u postgres psql -c "ALTER USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"

# Permissões
sudo -u postgres psql -c "ALTER DATABASE $DB_NAME OWNER TO $DB_USER;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
sudo -u postgres psql -d "$DB_NAME" -c "GRANT ALL ON SCHEMA public TO $DB_USER;"
sudo -u postgres psql -d "$DB_NAME" -c "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO $DB_USER;"
sudo -u postgres psql -d "$DB_NAME" -c "GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO $DB_USER;"
sudo -u postgres psql -d "$DB_NAME" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO $DB_USER;"

echo ""
echo "Banco criado com sucesso."
echo "DATABASE_URL para o .env do backend:"
echo "postgresql://$DB_USER:SEU_PASSWORD@localhost:5432/$DB_NAME"
echo "(Substitua SEU_PASSWORD pela senha que você definiu em DB_PASSWORD)"
echo ""
