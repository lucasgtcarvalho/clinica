# 🚀 Guia Rápido - Primeira Execução

## ⏱️ Tempo Total Estimado: 15-20 minutos

## Pré-requisitos (5 minutos)

Verifique se tem instalado:
```bash
node --version    # v18+
npm --version     # v9+
```

Se não tiver Node.js, baixe em: https://nodejs.org

## Backend Setup (5 minutos)

### 1. Terminal 1 - Navegar para backend
```bash
cd /var/www/html/clinica/backend
```

### 2. Instalar dependências
```bash
npm install
```

### 3. Configurar banco de dados
Edite o arquivo `.env` (copie de `.env.example` se não existir):

**Para PostgreSQL (Recomendado)**:
```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/clinic_saas"
JWT_SECRET="sua-chave-super-secreta-mudar-depois"
PORT=3000
NODE_ENV="development"
```

**Para MySQL**:
```env
DATABASE_URL="mysql://root:password@localhost:3306/clinic_saas"
JWT_SECRET="sua-chave-super-secreta-mudar-depois"
PORT=3000
NODE_ENV="development"
```

### 4. Criar banco de dados

**PostgreSQL**:
```bash
createdb clinic_saas
```

**MySQL**:
```bash
mysql -u root -p -e "CREATE DATABASE clinic_saas;"
```

### 5. Executar migrações
```bash
npm run prisma:push
```

### 6. Iniciar servidor
```bash
npm run dev
```

✅ Você deverá ver:
```
🚀 Server running on port 3000
Environment: development
```

## Frontend Setup (5 minutos)

### 1. Terminal 2 - Navegar para frontend
```bash
cd /var/www/html/clinica/frontend
```

### 2. Instalar dependências
```bash
npm install
```

### 3. Configurar arquivo .env
```env
VITE_API_URL=http://localhost:3000/api
VITE_APP_NAME=Clinic SaaS
```

### 4. Iniciar servidor
```bash
npm run dev
```

✅ Você deverá ver:
```
VITE v5.x.x  ready in XXX ms

➜  Local:   http://localhost:3001/
```

## Primeiro Acesso (5 minutos)

### 1. Abrir navegador
Acesse: **http://localhost:3001**

Será automaticamente redirecionado para `/login`

### 2. Criar Conta
Clique em "Criar conta" e preencha:
- **Nome**: Seu nome
- **Nome da Clínica**: Ex: "Clínica Beleza"
- **Email**: seu@email.com
- **Senha**: Uma senha segura

Clique em "Criar Conta"

### 3. Dashboard
Você será automaticamente logado e verá o dashboard com:
- 4 cards com estatísticas
- Menu de navegação no rodapé
- Links rápidos para funcionalidades

## ✨ Primeiras Ações Recomendadas

Agora explore os módulos:

### 1. Criar Serviços
- Vá para **Configurações** (ou acesse `/settings`)
- Crie alguns serviços: "Botox", "Limpeza de Pele", "Massagem Facial"

### 2. Criar Pacotes
- Crie um pacote com os serviços criados
- Ex: "Pacote Beleza" - 5 sessões

### 3. Cadastrar Cliente
- Menu **Clientes**
- Clique "Novo Cliente"
- Preencha dados e salve

### 4. Criar Agendamento
- Menu **Agenda**
- Clique em um horário vazio para criar
- Selecione cliente e serviços
- Salve

### 5. Registrar Transação
- Menu **Financeiro**
- "Nova Transação"
- Selecione cliente e valores
- Teste diferentes formas de pagamento

## 🐛 Troubleshooting Rápido

### "Port 3000 already in use"
```bash
# Encontrar processo
lsof -i :3000

# Matar processo (substituir 12345 por PID)
kill -9 12345
```

### "Can't reach database server"
Verificar:
- PostgreSQL/MySQL está rodando?
- Credenciais em `.env` estão corretas?
- Nome do banco existe?

```bash
# PostgreSQL
psql -U postgres -d clinic_saas -c "SELECT 1"

# MySQL
mysql -u root -p clinic_saas -e "SELECT 1"
```

### Módulos não encontrados
```bash
rm -rf node_modules package-lock.json
npm install
```

## 📚 Documentação Completa

Após primeiro acesso bem-sucedido, leia:
- [INSTALLATION.md](./INSTALLATION.md) - Guia detalhado
- [API.md](./API.md) - Endpoints e exemplos
- [ROADMAP.md](./ROADMAP.md) - Próximas features

## 🎯 Checklist de Sucesso

- [ ] Backend rodando em http://localhost:3000
- [ ] Frontend rodando em http://localhost:3001
- [ ] Conta criada com sucesso
- [ ] Página de dashboard carregando
- [ ] Menu de navegação visible
- [ ] Consegui criar um cliente
- [ ] Consegui criar um agendamento
- [ ] Consegui registrar uma transação

Se todas estão ✅, sua aplicação está pronta! 🎉

---

## 🆘 Precisa de Ajuda?

1. Verifique a aba **Console** do navegador (F12) para erros
2. Verifique o terminal onde o backend está rodando
3. Leia a documentação completa em `docs/`
4. Verifique variáveis de ambiente em `.env`

**Pronto? Vamos começar! 🚀**
