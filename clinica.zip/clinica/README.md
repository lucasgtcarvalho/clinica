# Clinic SaaS - Sistema de Gestão para Clínicas de Estética

Uma plataforma SaaS moderna e profissional para gestão completa de clínicas de estética, com foco em mobile-first (PWA), agenda inteligente, gestão de clientes, financeiro integrado e muito mais.

## 🎯 Características Principais

### 📅 Módulo de Agendamento
- Calendário interativo com FullCalendar
- Visualizações: Diária, Semanal e Mensal
- Drag-and-drop para reagendamento
- Múltiplos serviços por atendimento
- Status de atendimento customizáveis
- Bloqueio automático de horários indisponíveis

### 👥 Gestão de Clientes
- Cadastro completo com histórico
- Ficha de anamnese digital com assinatura eletrônica
- Histórico de atendimentos e valores pagos
- Upload de fotos antes/depois
- Controle de pacotes e créditos

### 💰 Módulo Financeiro
- Lançamentos automáticos ao finalizar atendimentos
- Controle de contas a receber
- Suporte a parcelamento
- Relatórios de faturamento (diário, semanal, mensal)
- Dashboard financeiro em tempo real
- Múltiplas formas de pagamento

### 🔐 Arquitetura SaaS
- Multi-tenant com isolamento de dados
- Controle de acesso granular
- Soft delete em todas as entidades
- Audit logs de ações
- Tema customizável por clínica

### 📱 Interface Mobile-First
- Bottom navigation fixa
- Design responsivo e intuitivo
- Otimizado para toque
- PWA ready
- Feedback visual completo

## 🛠️ Stack Tecnológico

### Backend
- **Node.js** + **Express**
- **TypeScript**
- **PostgreSQL** (ou MySQL)
- **Prisma ORM**
- **JWT** para autenticação
- **bcryptjs** para senhas

### Frontend
- **React 18** + **TypeScript**
- **Vite** como bundler
- **TailwindCSS** para estilos
- **FullCalendar** para agendamentos
- **Zustand** para state management
- **Axios** para requisições HTTP
- **React Router** para navegação

## 📦 Instalação

### Pré-requisitos
- Node.js >= 18
- PostgreSQL >= 12 (ou MySQL)
- npm ou yarn

### Backend

1. Acesse a pasta do backend:
```bash
cd backend
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
```bash
cp .env.example .env
```

4. Atualize o arquivo `.env` com suas credenciais:
```env
DATABASE_URL="postgresql://user:password@localhost:5432/clinic_saas"
JWT_SECRET="sua-chave-secreta-aqui"
PORT=3000
```

5. Execute as migrações do Prisma:
```bash
npm run prisma:migrate
```

6. Inicie o servidor:
```bash
npm run dev
```

### Frontend

1. Acesse a pasta do frontend:
```bash
cd frontend
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
```bash
cp .env.example .env
```

4. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

A aplicação estará disponível em `http://localhost:3001`

## 🗄️ Modelo de Dados

### Tabelas Principais

- **User**: Usuários do sistema
- **Clinic**: Clínicas (multi-tenant)
- **Client**: Clientes da clínica
- **Appointment**: Agendamentos
- **Service**: Serviços oferecidos
- **Package**: Pacotes de serviços
- **Transaction**: Transações financeiras
- **Anamnesis**: Fichas de anamnese com assinatura
- **Photo**: Fotos antes/depois
- **Professional**: Profissionais da clínica

## 📚 Rotas da API

### Autenticação
- `POST /api/auth/register` - Criar nova conta
- `POST /api/auth/login` - Fazer login
- `GET /api/auth/me` - Dados do usuário logado

### Agendamentos
- `GET /api/appointments` - Listar agendamentos
- `POST /api/appointments` - Criar agendamento
- `PUT /api/appointments/:id` - Atualizar agendamento
- `PATCH /api/appointments/:id/reschedule` - Reagendar (drag-drop)
- `DELETE /api/appointments/:id` - Cancelar agendamento

### Clientes
- `GET /api/clients` - Listar clientes
- `POST /api/clients` - Criar cliente
- `GET /api/clients/:id` - Obter cliente com histórico completo
- `PUT /api/clients/:id` - Atualizar cliente
- `DELETE /api/clients/:id` - Deletar cliente

### Financeiro
- `GET /api/finance` - Listar transações
- `POST /api/finance` - Criar transação
- `PATCH /api/finance/:id/mark-paid` - Marcar como pago
- `GET /api/finance/reports/general` - Relatórios
- `GET /api/finance/dashboard` - Dashboard financeiro

### Serviços e Pacotes
- `GET /api/services/services` - Listar serviços
- `POST /api/services/services` - Criar serviço
- `GET /api/services/packages` - Listar pacotes
- `POST /api/services/packages` - Criar pacote
- `POST /api/services/packages/add-to-client` - Vender pacote
- `PATCH /api/services/packages/use-session` - Usar sessão do pacote

### Anamnese
- `GET /api/anamnesis/client/:clientId` - Histórico de anamneses
- `POST /api/anamnesis` - Criar anamnese
- `PUT /api/anamnesis/:id` - Atualizar anamnese
- `PATCH /api/anamnesis/:id/sign` - Assinar digitalmente

## 🎨 Componentes Principais

### Frontend
- `Header` - Cabeçalho com dados do usuário
- `BottomNavigation` - Menu de navegação rodapé (mobile)
- `ProtectedRoute` - Rota protegida por autenticação
- `Loading` - Indicador de carregamento
- `Toast` - Notificações do sistema

### Páginas
- `LoginPage` - Página de login
- `RegisterPage` - Registro de nova clínica
- `DashboardPage` - Dashboard com estatísticas
- `AppointmentsPage` - Calendário de agendamentos
- `ClientsPage` - Lista de clientes
- `FinancePage` - Gestão financeira

## 🔒 Segurança

- Autenticação via JWT
- Senhas com bcrypt (salt 10)
- Validação de entrada em todas as rotas
- CORS configurado
- Soft delete em todos os registros
- Isolamento de dados por clínica

## 📊 Diferenciais Estratégicos

1. **Multi-tenant Completo**: Isolamento total de dados entre clínicas
2. **Anamnese com Assinatura Digital**: Validade jurídica básica (data, IP, usuário)
3. **Integração Automática**: Agenda → Atendimento → Financeiro
4. **Mobile-First**: Totalmente otimizado para tablets e celulares
5. **Dashboard Inteligente**: Visão em tempo real do negócio
6. **Extensível**: Preparado para WhatsApp, Email e Push Notifications
7. **Escalável**: Arquitetura SaaS pronta para crescimento

## 🚀 Próximos Passos

1. **Integrações de Notificação**
   - WhatsApp API
   - Email (SMTP)
   - Push Notifications

2. **Recursos Avançados**
   - Relatórios PDF
   - Integração com pagamentos (Stripe, PagSeguro)
   - Backup automático
   - SMS de lembretes

3. **Otimizações**
   - Caching com Redis
   - Processamento em background (Bull)
   - Compressão de imagens

## 📝 Licença

Este projeto é confidencial e desenvolvido especificamente para SaaS de clínicas de estética.

## 👨‍💻 Suporte

Para dúvidas ou problemas, consulte a documentação ou abra uma issue no repositório.

---

**Desenvolvido com ❤️ para clínicas de estética modernas**
