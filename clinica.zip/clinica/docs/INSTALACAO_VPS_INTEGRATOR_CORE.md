# Instalação do zero – Clinic SaaS na VPS Integrator Host (Plano VPS Linux Core)

Guia passo a passo para instalar o sistema **do zero** na VPS Linux Core da Integrator Host, com scripts prontos para executar no servidor.

---

## Índice

1. [Requisitos e informações do plano](#1-requisitos-e-informações-do-plano)
2. [Acesso SSH à VPS](#2-acesso-ssh-à-vps)
3. [Preparação do servidor (script ou manual)](#3-preparação-do-servidor)
4. [Instalação do Node.js](#4-instalação-do-nodejs)
5. [Instalação do PostgreSQL](#5-instalação-do-postgresql)
6. [Criação do banco e usuário](#6-criação-do-banco-e-usuário)
7. [Envio do código para a VPS](#7-envio-do-código-para-a-vps)
8. [Deploy do backend](#8-deploy-do-backend)
9. [Build e deploy do frontend](#9-build-e-deploy-do-frontend)
10. [Configuração do Nginx](#10-configuração-do-nginx)
11. [Variáveis de ambiente e CORS](#11-variáveis-de-ambiente-e-cors)
12. [Usar apenas IP (sem domínio)](#12-usar-apenas-ip-sem-dominio)
13. [SSL/HTTPS (com domínio)](#13-sslhttps-com-dominio)
14. [Checklist e testes](#14-checklist-e-testes)
15. [Troubleshooting](#15-troubleshooting)

---

## 1. Requisitos e informações do plano

### Plano VPS Linux Core (Integrator Host)

- Acesso **root** ou usuário com **sudo**.
- Sistema recomendado: **Ubuntu 20.04** ou **Ubuntu 22.04**.
- Você vai precisar de:
  - **IP da VPS**
  - **Usuário** (ex.: `root` ou o usuário criado no painel)
  - **Senha** ou chave SSH

### O que será instalado

| Item            | Versão sugerida | Uso                    |
|-----------------|-----------------|------------------------|
| Node.js         | 18.x LTS        | Backend e build frontend |
| PostgreSQL      | 12+             | Banco de dados         |
| Nginx           | 1.18+           | Servir frontend e proxy para API |
| PM2             | 5.x             | Manter backend rodando |

---

## 2. Acesso SSH à VPS

### No Windows (PowerShell ou CMD)

```powershell
ssh root@SEU_IP_DA_VPS
```

Quando perguntar se confia no host, digite: **yes**  
Depois informe a **senha** recebida no painel da Integrator Host.

### No Linux ou Mac

```bash
ssh root@SEU_IP_DA_VPS
```

### Conferir se está dentro do servidor

Você deve ver um prompt como:

```text
root@vps123:~#
```

Anote o **IP** da VPS (ex.: `200.123.45.67`). Você usará em vários passos.

---

## 3. Preparação do servidor

Atualize o sistema e instale ferramentas básicas.

### Opção A: Script automático

No seu computador, na pasta do projeto, há um script que pode ser **copiado e colado** no terminal da VPS (ou enviado por SCP e executado). Execute **no servidor**, como root:

```bash
# No VPS, após conectar por SSH:
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git build-essential ufw
```

### Opção B: Passo a passo manual

```bash
# 1. Atualizar lista de pacotes
sudo apt update

# 2. Atualizar pacotes instalados
sudo apt upgrade -y

# 3. Instalar ferramentas úteis
sudo apt install -y curl wget git build-essential
```

### (Opcional) Criar usuário não-root

Recomendado para produção: usar um usuário (ex.: `clinic`) em vez de `root`.

```bash
sudo adduser clinic
sudo usermod -aG sudo clinic
# Trocar para o usuário:
su - clinic
```

Nos próximos comandos, se estiver como `clinic`, use `sudo` quando for necessário.

---

## 4. Instalação do Node.js

Node.js 18 LTS (recomendado para o projeto).

```bash
# 1. Adicionar repositório NodeSource
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -

# 2. Instalar Node.js
sudo apt install -y nodejs

# 3. Conferir
node --version   # deve mostrar v18.x.x
npm --version    # deve mostrar 9.x ou 10.x
```

Se preferir **NVM** (várias versões de Node no mesmo servidor):

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 18
nvm use 18
nvm alias default 18
node --version
```

---

## 5. Instalação do PostgreSQL

```bash
sudo apt install -y postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
sudo systemctl status postgresql
```

O status deve indicar **active (running)**.

---

## 6. Criação do banco e usuário

Escolha uma **senha forte** para o usuário do banco (ex.: `MinhaS3nhaSegura!2024`). Substitua nos comandos abaixo.

### Opção A: Script (ajuste a senha antes)

O projeto inclui o script `scripts/02-setup-database.sh`. Nele, edite a variável `DB_PASSWORD` e execute no servidor (com o código do projeto já na VPS):

```bash
# Dentro da pasta do projeto no servidor:
chmod +x scripts/02-setup-database.sh
export DB_PASSWORD="MinhaS3nhaSegura!2024"
./scripts/02-setup-database.sh
```

### Opção B: Manual

```bash
sudo -u postgres psql
```

No console do PostgreSQL:

```sql
CREATE DATABASE clinic_saas;
CREATE USER clinic_user WITH PASSWORD 'MinhaS3nhaSegura!2024';
ALTER DATABASE clinic_saas OWNER TO clinic_user;
GRANT ALL PRIVILEGES ON DATABASE clinic_saas TO clinic_user;
\c clinic_saas
GRANT ALL ON SCHEMA public TO clinic_user;
\q
```

Teste (no Linux, como usuário do SO):

```bash
psql -h localhost -U clinic_user -d clinic_saas -c "SELECT 1;"
```

Se pedir senha, use a que você definiu. Se retornar `1`, a conexão está OK.

Anote:
- **Banco:** `clinic_saas`
- **Usuário:** `clinic_user`
- **Senha:** a que você definiu
- **Host:** `localhost`
- **Porta:** `5432`

A URL de conexão fica:

```text
postgresql://clinic_user:MinhaS3nhaSegura!2024@localhost:5432/clinic_saas
```

(Em senhas com caracteres especiais, pode ser necessário usar encoding na URL.)

---

## 7. Envio do código para a VPS

O backend precisa estar **na VPS** para instalar dependências, rodar Prisma e subir com PM2. O frontend pode ser buildado no seu PC e só a pasta `dist` enviada, ou buildado na própria VPS.

### Opção A: Enviar pasta do projeto com SCP (do seu PC)

No **seu computador** (PowerShell ou terminal), na pasta onde está o projeto (ex.: `c:\Users\LUCAS\Desktop\clinica`):

```powershell
# Windows PowerShell - enviar projeto inteiro
scp -r .\backend .\frontend .\scripts .\docs root@SEU_IP_DA_VPS:/home/root/clinica/
```

Ajuste `root` e `/home/root/clinica/` se estiver usando outro usuário (ex.: `clinic` e `/home/clinic/clinica/`).

### Opção B: Git (se o projeto estiver em um repositório)

Na VPS:

```bash
sudo apt install -y git
cd /home/root   # ou /home/clinic
git clone https://github.com/SEU_USUARIO/clinica.git
cd clinica
```

### Estrutura esperada na VPS

Algo como:

```text
/home/root/clinica/   (ou /home/clinic/clinica/)
├── backend/
│   ├── src/
│   ├── prisma/
│   ├── package.json
│   └── ...
├── frontend/
│   ├── src/
│   ├── package.json
│   ├── vite.config.ts
│   └── ...
├── scripts/
│   ├── 01-setup-vps.sh
│   ├── 02-setup-database.sh
│   ├── 03-deploy-backend.sh
│   └── ...
└── docs/
```

---

## 8. Deploy do backend

Tudo a partir daqui é **no servidor**, via SSH.

### 8.1 Ir para a pasta do backend

```bash
cd /home/root/clinica/backend
# ou: cd /home/clinic/clinica/backend
```

### 8.2 Instalar dependências

```bash
npm install
```

### 8.3 Criar arquivo `.env`

```bash
nano .env
```

Cole o conteúdo abaixo e **ajuste**:

- `DATABASE_URL`: mesma senha e dados do banco que você criou.
- `JWT_SECRET`: gere uma chave forte (veja comando abaixo).
- `FRONTEND_URL`: URL que o usuário usará no navegador (com domínio ou com IP).

Exemplo **com domínio**:

```env
DATABASE_URL="postgresql://clinic_user:MinhaS3nhaSegura!2024@localhost:5432/clinic_saas"
JWT_SECRET="COLE_AQUI_A_CHAVE_GERADA"
JWT_EXPIRES_IN="7d"
PORT=3000
NODE_ENV="production"
FRONTEND_URL="https://seudominio.com.br"
```

Exemplo **só com IP**:

```env
DATABASE_URL="postgresql://clinic_user:MinhaS3nhaSegura!2024@localhost:5432/clinic_saas"
JWT_SECRET="COLE_AQUI_A_CHAVE_GERADA"
JWT_EXPIRES_IN="7d"
PORT=3000
NODE_ENV="production"
FRONTEND_URL="http://SEU_IP_DA_VPS"
```

Gerar **JWT_SECRET** (execute na VPS):

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copie a saída e substitua em `JWT_SECRET` no `.env`.  
Salvar no `nano`: **Ctrl+O**, Enter, **Ctrl+X**.

### 8.4 Ajustar CORS no código (se necessário)

O backend usa `FRONTEND_URL` para CORS (em `server.ts`). Não use `http://localhost` em produção. Mantenha apenas `FRONTEND_URL` no `.env` como acima.

### 8.5 Prisma: generate e migrations

```bash
npx prisma generate
npx prisma migrate deploy
```

Se não houver migrations ainda (primeira vez), pode usar:

```bash
npx prisma db push
```

### 8.6 Build do backend (TypeScript)

```bash
npm run build
```

### 8.7 Instalar PM2 e subir a API

```bash
sudo npm install -g pm2
pm2 start dist/server.js --name clinic-api
pm2 save
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u root --hp /root
```

(Se estiver como usuário `clinic`, use `-u clinic --hp /home/clinic`.)

### 8.8 Conferir

```bash
pm2 status
curl http://localhost:3000/health
```

A resposta esperada é algo como: `{"status":"Server is running"}`.

---

## 9. Build e deploy do frontend

O frontend precisa saber a URL da API em produção. Isso é definido na **build** pela variável `VITE_API_URL`.

### 9.1 Build no seu computador (recomendado)

No **seu PC**, na pasta do projeto:

```bash
cd frontend
```

Crie ou edite o `.env` (ou `.env.production`):

- **Com domínio:**  
  `VITE_API_URL=https://seudominio.com.br/api`
- **Só IP:**  
  `VITE_API_URL=http://SEU_IP_DA_VPS/api`

Exemplo `.env.production`:

```env
VITE_API_URL=https://seudominio.com.br/api
VITE_APP_NAME=Clinic SaaS
```

Depois:

```bash
npm install
npm run build
```

Isso gera a pasta `dist/`. Envie **só o conteúdo** de `dist/` para a VPS:

```powershell
# No seu PC (PowerShell), a partir da pasta frontend:
scp -r dist/* root@SEU_IP_DA_VPS:/home/root/clinica/frontend-dist/
```

Na VPS, crie o diretório se não existir:

```bash
mkdir -p /home/root/clinica/frontend-dist
```

E depois use o `scp` acima. A ideia é que em `/home/root/clinica/frontend-dist/` fiquem `index.html`, `assets/`, etc.

### 9.2 Build na VPS (alternativa)

Na VPS:

```bash
cd /home/root/clinica/frontend
echo 'VITE_API_URL=http://SEU_IP_DA_VPS/api' > .env.production
echo 'VITE_APP_NAME=Clinic SaaS' >> .env.production
npm install
npm run build
mkdir -p /home/root/clinica/frontend-dist
cp -r dist/* /home/root/clinica/frontend-dist/
```

Substitua `http://SEU_IP_DA_VPS/api` pelo domínio se for o caso (ex.: `https://seudominio.com.br/api`).

---

## 10. Configuração do Nginx

Nginx serve o frontend (arquivos estáticos) e repassa `/api/` para o backend (porta 3000).

### 10.1 Instalar Nginx

```bash
sudo apt install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 10.2 Criar configuração do site

```bash
sudo nano /etc/nginx/sites-available/clinic
```

Cole uma das configurações abaixo.

**Se você usa domínio** (substitua `seudominio.com.br`):

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name seudominio.com.br www.seudominio.com.br;

    root /home/root/clinica/frontend-dist;
    index index.html;

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    client_max_body_size 100M;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
}
```

**Se você usa só IP** (substitua `/home/root` por `/home/clinic` se for o caso):

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name _;

    root /home/root/clinica/frontend-dist;
    index index.html;

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    client_max_body_size 100M;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
}
```

Salvar: **Ctrl+O**, Enter, **Ctrl+X**.

### 10.3 Ativar site e recarregar Nginx

```bash
sudo ln -sf /etc/nginx/sites-available/clinic /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

Se `nginx -t` mostrar **syntax is ok**, está correto.

---

## 11. Variáveis de ambiente e CORS

Resumo do que o backend usa (arquivo `.env` na pasta `backend/`):

| Variável       | Obrigatório | Exemplo |
|----------------|-------------|---------|
| `DATABASE_URL` | Sim         | `postgresql://clinic_user:SENHA@localhost:5432/clinic_saas` |
| `JWT_SECRET`   | Sim         | String longa e aleatória (32+ caracteres) |
| `PORT`         | Não         | `3000` (padrão) |
| `NODE_ENV`     | Não         | `production` |
| `FRONTEND_URL` | Sim (CORS)  | `https://seudominio.com.br` ou `http://SEU_IP` |

O frontend usa na **hora do build**:

| Variável         | Uso |
|------------------|-----|
| `VITE_API_URL`   | URL base da API (ex.: `https://seudominio.com.br/api` ou `http://IP/api`) |
| `VITE_APP_NAME`  | Nome da aplicação (opcional) |

**Importante:** `FRONTEND_URL` no backend deve ser **exatamente** a URL que o usuário digita no navegador (com ou sem barra no final, conforme o que você usar). Se usar só IP, deve ser `http://SEU_IP` (sem porta se for 80).

---

## 12. Usar apenas IP (sem domínio)

1. No backend `.env`:  
   `FRONTEND_URL="http://SEU_IP_DA_VPS"`
2. No frontend (build):  
   `VITE_API_URL=http://SEU_IP_DA_VPS/api`
3. Nginx: use o bloco com `server_name _;` e `root` apontando para `frontend-dist`.
4. Acesso:  
   - Frontend: `http://SEU_IP_DA_VPS`  
   - API: `http://SEU_IP_DA_VPS/api/...`

Não é possível usar Let's Encrypt só com IP; para HTTPS é necessário um domínio.

---

## 13. SSL/HTTPS (com domínio)

Com domínio apontando para o IP da VPS:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d seudominio.com.br -d www.seudominio.com.br
```

Siga as perguntas (e-mail, termos). Depois:

```bash
sudo nginx -t
sudo systemctl reload nginx
```

Atualize o `.env` do backend:

```env
FRONTEND_URL="https://seudominio.com.br"
```

E no frontend (próximas builds):

```env
VITE_API_URL=https://seudominio.com.br/api
```

Gere novo build do frontend e envie de novo para `frontend-dist/`. Reinicie a API se mudou algo no backend:

```bash
pm2 restart clinic-api
```

---

## 14. Checklist e testes

- [ ] SSH na VPS funcionando  
- [ ] Node 18 e npm instalados  
- [ ] PostgreSQL instalado e rodando  
- [ ] Banco `clinic_saas` e usuário `clinic_user` criados  
- [ ] Código do projeto na VPS (backend + frontend ou só dist)  
- [ ] Backend: `.env` com `DATABASE_URL`, `JWT_SECRET`, `FRONTEND_URL`  
- [ ] Backend: `npx prisma generate` e `migrate deploy` (ou `db push`)  
- [ ] Backend: `npm run build` e `pm2 start`  
- [ ] `curl http://localhost:3000/health` responde OK  
- [ ] Frontend buildado com `VITE_API_URL` correto  
- [ ] Conteúdo de `dist/` em `frontend-dist/` na VPS  
- [ ] Nginx configurado (site clinic ativo, default desativado)  
- [ ] `sudo nginx -t` OK e Nginx recarregado  
- [ ] No navegador: abrir a URL (domínio ou IP) e ver a tela de login  
- [ ] Criar conta e fazer login; acessar dashboard e uma tela que chame a API  

---

## 15. Troubleshooting

### 502 Bad Gateway

- Backend não está rodando ou não está na porta 3000.  
  `pm2 status` e `pm2 logs clinic-api`. Subir de novo com `pm2 start dist/server.js --name clinic-api`.

### CORS no navegador

- Conferir `FRONTEND_URL` no `.env` do backend (mesma origem que a barra de endereço do navegador).  
  Reiniciar: `pm2 restart clinic-api`.

### Página em branco ou 404 no frontend

- Verificar se `root` no Nginx aponta para a pasta onde está `index.html` (ex.: `frontend-dist`).  
- Verificar se o build do frontend usou a `VITE_API_URL` correta.

### Erro de conexão com o banco

- PostgreSQL rodando: `sudo systemctl status postgresql`.  
- Testar: `psql -h localhost -U clinic_user -d clinic_saas`.  
- Conferir `DATABASE_URL` no `.env` (usuário, senha, nome do banco).

### Comandos úteis

```bash
pm2 status
pm2 logs clinic-api
pm2 restart clinic-api
sudo systemctl status nginx
sudo tail -f /var/log/nginx/error.log
curl http://localhost:3000/health
```

---

**Versão:** 1.0 – Integrator Host VPS Linux Core  
**Projeto:** Clinic SaaS
