# 📚 Guia Completo de Instalação e Uso

## 1️⃣ Configuração Inicial do Projeto

### Pré-requisitos
Certifique-se de ter instalado:
- **Node.js** v18+ ([Download](https://nodejs.org))
- **PostgreSQL** v12+ ([Download](https://www.postgresql.org/download)) ou **MySQL** v5.7+
- **Git** (opcional, mas recomendado)

### Verificar Instalação
```bash
node --version  # Deve ser v18 ou superior
npm --version
psql --version # Para PostgreSQL
```

## 2️⃣ Configurar Backend

### Passo 1: Entrar na pasta backend
```bash
cd /var/www/html/clinica/backend
```

### Passo 2: Instalar dependências
```bash
npm install
```

### Passo 3: Configurar banco de dados

#### Opção A: PostgreSQL
```sql
-- Criar database
CREATE DATABASE clinic_saas;

-- Criar usuário (opcional)
CREATE USER clinic_user WITH PASSWORD 'senha_segura';
ALTER ROLE clinic_user CREATEDB;
GRANT ALL PRIVILEGES ON DATABASE clinic_saas TO clinic_user;
```

#### Opção B: MySQL
```sql
CREATE DATABASE clinic_saas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'clinic_user'@'localhost' IDENTIFIED BY 'senha_segura';
GRANT ALL PRIVILEGES ON clinic_saas.* TO 'clinic_user'@'localhost';
FLUSH PRIVILEGES;
```

### Passo 4: Configurar variáveis de ambiente
```bash
cp .env.example .env
```

Editar `.env`:
```env
# PostgreSQL
DATABASE_URL="postgresql://clinic_user:senha_segura@localhost:5432/clinic_saas"

# Ou MySQL
# DATABASE_URL="mysql://clinic_user:senha_segura@localhost:3306/clinic_saas"

JWT_SECRET="sua_chave_super_secreta_aqui_mudar_em_producao"
JWT_EXPIRES_IN="7d"
PORT=3000
NODE_ENV="development"
```

### Passo 5: Executar migrações
```bash
# Gerar Prisma Client
npm run prisma:generate

# Criar tabelas no banco
npm run prisma:push
```

Ou com migração nomeada:
```bash
npm run prisma:migrate -- --name initial_setup
```

### Passo 6: Iniciar servidor backend
```bash
npm run dev
```

✅ Backend rodando em `http://localhost:3000`

## 3️⃣ Configurar Frontend

### Passo 1: Abrir nova aba/terminal
```bash
cd /var/www/html/clinica/frontend
```

### Passo 2: Instalar dependências
```bash
npm install
```

### Passo 3: Configurar variáveis de ambiente
```bash
cp .env.example .env
```

Editar `.env`:
```env
VITE_API_URL=http://localhost:3000/api
VITE_APP_NAME="Clinic SaaS"
```

### Passo 4: Iniciar servidor frontend
```bash
npm run dev
```

✅ Frontend rodando em `http://localhost:3001`

## 4️⃣ Acessar a Aplicação

1. Abra seu navegador
2. Acesse: **http://localhost:3001**
3. Você será redirecionado para `/login`

## 5️⃣ Criar Primeira Conta

### Na página de login:
1. Clique em "Criar conta"
2. Preencha os dados:
   - **Nome Completo**: Seu nome
   - **Nome da Clínica**: Nome da sua clínica
   - **Email**: seu@email.com
   - **Senha**: Senha segura
3. Clique em "Criar Conta"
4. Será feito login automaticamente e redirecionado ao dashboard

## 6️⃣ Primeiro Acesso - Checklist

Após criar a conta, complete os itens:

- [ ] Ir para **Configurações** e atualizar dados da clínica
- [ ] Criar **Serviços** (procedimentos oferecidos)
- [ ] Criar **Pacotes** (combos de serviços)
- [ ] Cadastrar **Clientes** iniciais
- [ ] Criar primeiro **Agendamento**
- [ ] Testar visualizações de calendário (Dia/Semana/Mês)
- [ ] Registrar uma **Transação** de teste
- [ ] Verificar **Dashboard** financeiro

## 7️⃣ Estrutura de Pastas

```
clinica/
├── backend/                    # API REST
│   ├── src/
│   │   ├── controllers/       # Lógica de negócio
│   │   ├── routes/            # Endpoints
│   │   ├── services/          # Serviços auxiliares
│   │   ├── middlewares/       # Auth, erro, etc
│   │   ├── types/             # TypeScript DTOs
│   │   ├── utils/             # Funções úteis
│   │   └── server.ts          # Arquivo principal
│   ├── prisma/
│   │   └── schema.prisma      # Modelo de dados
│   ├── package.json
│   ├── tsconfig.json
│   └── .env                   # Variáveis de ambiente
│
├── frontend/                   # Aplicação React
│   ├── src/
│   │   ├── pages/             # Páginas principais
│   │   ├── components/        # Componentes reutilizáveis
│   │   ├── services/          # Chamadas à API
│   │   ├── store/             # Zustand (state management)
│   │   ├── types/             # Types TypeScript
│   │   ├── hooks/             # Custom hooks
│   │   ├── utils/             # Utilidades
│   │   ├── App.tsx            # Componente principal
│   │   ├── main.tsx           # Entrada
│   │   └── index.css          # Estilos globais
│   ├── index.html
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── .env                   # Variáveis de ambiente
│
├── docs/                      # Documentação
└── README.md
```

## 8️⃣ Comandos Úteis

### Backend
```bash
# Desenvolvimento
npm run dev

# Build para produção
npm run build

# Iniciar build em produção
npm start

# Regenerar Prisma Client
npm run prisma:generate

# Criar migração nomeada
npm run prisma:migrate

# Abrir Prisma Studio (visualizar DB graficamente)
npm run prisma:studio

# Sincronizar schema com banco
npm run prisma:push
```

### Frontend
```bash
# Desenvolvimento
npm run dev

# Build para produção
npm run build

# Preview do build
npm run preview

# Lint
npm run lint
```

## 9️⃣ Troubleshooting

### Backend não conecta ao banco

**Erro**: `Error: P1000 Can't reach database server`

**Solução**:
```bash
# Verificar se PostgreSQL está rodando
# Linux/Mac:
brew services list

# Windows:
# Procure por "PostgreSQL" em Serviços do Windows

# Verificar string de conexão em .env
psql -U postgres -d postgres -c "SELECT version();"
```

### Porta já em uso

**Erro**: `Port 3000 is already in use`

**Solução**:
```bash
# Linux/Mac - Encontrar e matar processo
lsof -i :3000
kill -9 <PID>

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Módulos não encontrados

**Erro**: `Cannot find module...`

**Solução**:
```bash
# Limpar node_modules e reinstalar
rm -rf node_modules package-lock.json
npm install
```

### Erro ao migrar banco de dados

**Solução**:
```bash
# Redefinir Prisma (cuidado em produção!)
npx prisma migrate reset

# Ou empurrar schema sem histórico
npm run prisma:push
```

## 🔟 Variáveis de Ambiente Detalhadas

### Backend (.env)
```env
# Banco de dados
DATABASE_URL="postgresql://user:password@host:port/db"

# Autenticação
JWT_SECRET="chave-super-secreta-mudar-em-producao"
JWT_EXPIRES_IN="7d"

# Servidor
PORT=3000
NODE_ENV="development"

# Upload de arquivos
UPLOAD_DIR="./uploads"
MAX_FILE_SIZE=5242880  # 5MB em bytes

# SMTP para email (opcional)
SMTP_HOST="smtp.gmail.com"
SMTP_PORT=587
SMTP_USER="seu-email@gmail.com"
SMTP_PASS="sua-senha-app"

# WhatsApp (opcional)
WHATSAPP_API_TOKEN=""
WHATSAPP_BUSINESS_ID=""

# AWS S3 para imagens (opcional)
AWS_ACCESS_KEY_ID=""
AWS_SECRET_ACCESS_KEY=""
AWS_S3_BUCKET=""
AWS_REGION="us-east-1"
```

### Frontend (.env)
```env
# URL da API
VITE_API_URL=http://localhost:3000/api

# Nome da app
VITE_APP_NAME="Clinic SaaS"
```

## 1️⃣1️⃣ Deploy (Produção)

### Backend no Heroku
```bash
heroku login
heroku create seu-app-name
git push heroku main
```

### Frontend no Vercel
```bash
npm install -g vercel
vercel
# Seguir instruções
```

## 1️⃣2️⃣ Testes de Funcionalidade

### 1. Autenticação
- [ ] Register nova clínica
- [ ] Login com credenciais corretas
- [ ] Login falhar com credenciais incorretas
- [ ] Logout funcionar

### 2. Agendamentos
- [ ] Visualizar calendário mês/semana/dia
- [ ] Criar novo agendamento
- [ ] Editar agendamento
- [ ] Arrastar para reagendar (drag-drop)
- [ ] Cancelar agendamento

### 3. Clientes
- [ ] Listar clientes
- [ ] Criar novo cliente
- [ ] Buscar cliente por nome/telefone
- [ ] Visualizar histórico completo
- [ ] Editar dados do cliente

### 4. Financeiro
- [ ] Criar transação manual
- [ ] Listar transações com filtros
- [ ] Marcar como pago
- [ ] Ver dashboard com estatísticas
- [ ] Gerar relatório por período

## 1️⃣3️⃣ Suporte e Recursos

- 📖 [Documentação do Prisma](https://www.prisma.io/docs/)
- ⚛️ [Documentação React](https://react.dev)
- 🎨 [Documentação TailwindCSS](https://tailwindcss.com/docs)
- 🛣️ [React Router](https://reactrouter.com)
- 📅 [FullCalendar](https://fullcalendar.io)

---

**Pronto! Sua aplicação SaaS está rodando! 🚀**
