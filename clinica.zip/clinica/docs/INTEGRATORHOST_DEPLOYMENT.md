# 🚀 Deploy na Integratorhost VPS - Guia Completo

**Data**: Janeiro 2026  
**Versão**: 1.0.0  
**Status**: ✅ Pronto para Produção

---

## 📋 Índice

1. [Escolher Plano Integratorhost](#-escolher-plano-integratorhost)
2. [Acesso Inicial SSH](#-acesso-inicial-ssh)
3. [Preparação e Ambiente](#-preparação-e-ambiente)
4. [Instalação Node.js](#-instalação-nodejs)
5. [Instalação Banco de Dados](#-instalação-banco-de-dados)
6. [Deploy Backend](#-deploy-backend)
7. [Deploy Frontend](#-deploy-frontend)
8. [Configurar Domínio](#-configurar-domínio)
9. [SSL/HTTPS](#-sslhttps)
10. [Otimizações](#-otimizações)
11. [Troubleshooting](#-troubleshooting)

---

## 🎯 Escolher Plano Integratorhost

### Planos Recomendados

**VPS Cloud 1** (Básico - Início)
- 1 vCPU
- 2 GB RAM
- 40 GB SSD
- ~R$ 25-35/mês
- ✅ Adequado para começar

**VPS Cloud 2** (Recomendado) ⭐
- 2 vCPU
- 4 GB RAM
- 80 GB SSD
- ~R$ 45-60/mês
- ✅ Melhor custo-benefício

**VPS Cloud 4** (Produção)
- 4 vCPU
- 8 GB RAM
- 160 GB SSD
- ~R$ 90-120/mês
- ✅ Para produção escalada

### Após contratação:
1. Acesse painel Integratorhost
2. Vá em **Serviços → VPS Cloud**
3. Copie: IP, Usuário (root ou usuário), Senha raiz
4. Anote o **Sistema Operacional** instalado (Ubuntu 20.04/22.04 recomendado)

---

## 🔑 Acesso Inicial SSH

### Conectar ao VPS

**Windows (CMD ou PowerShell):**
```bash
ssh root@SEU_IP_DO_VPS
# Digite a senha quando solicitado
```

**Linux/Mac (Terminal):**
```bash
ssh root@SEU_IP_DO_VPS
```

**Primeiro acesso:**
```bash
# Será solicitado: "Are you sure you want to continue connecting?" 
# Digite: yes

# Digite a senha fornecida pela Integratorhost
```

---

## 🔧 Preparação e Ambiente

### Passo 1: Atualizar Sistema

```bash
# Conectado via SSH no VPS, execute:
sudo apt update && sudo apt upgrade -y

# Instalar ferramentas essenciais
sudo apt install -y curl wget git build-essential
```

### Passo 2: Criar Usuário Não-Root (Recomendado)

```bash
# Criar novo usuário
sudo useradd -m -s /bin/bash clinic

# Definir senha
sudo passwd clinic

# Adicionar ao grupo sudo (permissões administrativas)
sudo usermod -aG sudo clinic

# Trocar para novo usuário
su - clinic
```

> A partir daqui, use `sudo` para comandos que precisam privilégio

### Passo 3: Desabilitar SSH com Senha (Segurança)

```bash
# Este passo é opcional mas recomendado
# Gera chave SSH local e coloca no servidor

# No seu COMPUTADOR LOCAL (não no VPS):
ssh-keygen -t rsa -b 4096

# Copiar chave pública para VPS
ssh-copy-id -i ~/.ssh/id_rsa.pub clinic@SEU_IP_DO_VPS

# Agora pode conectar sem password:
ssh clinic@SEU_IP_DO_VPS
```

---

## 📦 Instalação Node.js

### Instalar Node.js 18 LTS (Recomendado)

```bash
# No VPS, conectado como clinic:

# Adicionar repositório NodeSource
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -

# Instalar Node.js
sudo apt install -y nodejs

# Verificar versão
node --version    # deve mostrar v18.x.x
npm --version     # deve mostrar v9.x.x
```

### Alternativamente: NVM (Node Version Manager)

```bash
# Se preferir gerenciar múltiplas versões
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# Recarregar shell
source ~/.bashrc

# Instalar Node 18
nvm install 18
nvm use 18
nvm alias default 18

# Verificar
node --version
```

---

## 💾 Instalação Banco de Dados

### Opção A: PostgreSQL (Recomendado)

```bash
# Instalar PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Iniciar serviço
sudo systemctl start postgresql
sudo systemctl enable postgresql  # Iniciar no boot

# Verificar status
sudo systemctl status postgresql
```

**Criar banco e usuário:**

```bash
# Entrar no PostgreSQL
sudo -u postgres psql

# Dentro do console PostgreSQL, execute:
CREATE DATABASE clinic_saas;
CREATE USER clinic_user WITH PASSWORD 'sua_senha_super_segura_123!';
GRANT ALL PRIVILEGES ON DATABASE clinic_saas TO clinic_user;
ALTER DATABASE clinic_saas OWNER TO clinic_user;
\q
```

**Testar conexão:**

```bash
# Do usuário clinic no VPS:
psql -h localhost -U clinic_user -d clinic_saas
# Digite a senha criada

# Se conectar com sucesso, digite:
\q
```

### Opção B: MySQL/MariaDB

```bash
# Instalar MariaDB (compatível com MySQL)
sudo apt install -y mariadb-server mariadb-client

# Iniciar
sudo systemctl start mariadb
sudo systemctl enable mariadb

# Setup seguro (recomendado)
sudo mysql_secure_installation
# Responder:
# - Remove anonymous users? Y
# - Disable remote root login? Y
# - Remove test database? Y
# - Reload tables? Y
```

**Criar banco e usuário:**

```bash
# Conectar ao MySQL
sudo mysql -u root

# Executar:
CREATE DATABASE clinic_saas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'clinic_user'@'localhost' IDENTIFIED BY 'sua_senha_super_segura_123!';
GRANT ALL PRIVILEGES ON clinic_saas.* TO 'clinic_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## 🚀 Deploy Backend

### Passo 1: Criar Estrutura de Diretórios

```bash
# No VPS, como usuário clinic:
mkdir -p /home/clinic/apps
cd /home/clinic/apps

# Listar para confirmar
ls -la
```

### Passo 2: Clonar ou Fazer Upload do Código

**Opção A: Clonar do Git**

```bash
cd /home/clinic/apps

# Clonar repositório
git clone https://github.com/seu-usuario/clinica.git

cd clinica/backend

# Ou se repositório privado (usar SSH):
git clone git@github.com:seu-usuario/clinica.git
```

**Opção B: Upload via SCP (do seu computador LOCAL)**

```bash
# No seu COMPUTADOR (não no VPS), execute:

# Compactar pasta backend
cd /var/www/html/clinica
tar -czf backend.tar.gz backend/

# Enviar para VPS
scp backend.tar.gz clinic@SEU_IP_DO_VPS:/home/clinic/apps/

# No VPS, descompactar:
cd /home/clinic/apps
tar -xzf backend.tar.gz
rm backend.tar.gz
```

### Passo 3: Instalar Dependências

```bash
cd /home/clinic/apps/clinica/backend

# Instalar dependências de produção
npm install --production

# Ou todos (com dev):
npm install
```

### Passo 4: Configurar Variáveis de Ambiente

```bash
# Criar arquivo .env
nano .env

# Colar este conteúdo (ADAPTE os valores):
```

```env
# Database (escolha conforme instalado acima)
DATABASE_URL="postgresql://clinic_user:sua_senha_super_segura_123!@localhost:5432/clinic_saas"
# Ou MySQL:
# DATABASE_URL="mysql://clinic_user:sua_senha_super_segura_123!@localhost:3306/clinic_saas"

# JWT - GERE UMA CHAVE SEGURA!
JWT_SECRET="abc123def456ghi789jkl012mno345pqr"
JWT_EXPIRES_IN="7d"

# Servidor
PORT=3000
NODE_ENV="production"

# CORS - ALTERE PARA SEU DOMÍNIO
CORS_ORIGIN="https://seudominio.com.br"

# Email (opcional, para Phase 2)
SMTP_HOST="smtp.seu-email.com"
SMTP_PORT="587"
SMTP_USER="seu-email@exemplo.com"
SMTP_PASS="sua-senha-app"
```

**Gerar JWT_SECRET seguro:**

```bash
# Executar no VPS (gera chave aleatória):
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Copie a saída e substitua no .env
```

**Salvar arquivo:**
```
Pressione: Ctrl+O, Enter, Ctrl+X
```

### Passo 5: Setup Prisma

```bash
cd /home/clinic/apps/clinica/backend

# Executar migrations
npx prisma migrate deploy

# Gerar Prisma Client
npx prisma generate

# Verificar se criou seed data (se existir)
# npx prisma db seed
```

### Passo 6: Instalar PM2 (Gerenciador de Processos)

```bash
# Instalar globalmente
sudo npm install -g pm2

# Usar PM2 como usuário clinic (recomendado)
sudo pm2 install pm2-logrotate

# Verificar
pm2 --version
```

### Passo 7: Iniciar Backend com PM2

```bash
cd /home/clinic/apps/clinica/backend

# Iniciar aplicação
pm2 start npm --name "clinic-api" -- start

# Salvar configuração (para sobreviver reboot)
pm2 save

# Configurar para iniciar no boot
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u clinic --hp /home/clinic

# Verificar status
pm2 status
pm2 logs clinic-api
```

**Verificação rápida:**

```bash
# Teste local no VPS
curl http://localhost:3000

# Deve retornar erro 404 ou mensagem de API
```

---

## 🎨 Deploy Frontend

### Passo 1: Build Local

```bash
# No seu COMPUTADOR LOCAL, não no VPS:
cd /var/www/html/clinica/frontend

# Build otimizado
npm run build

# Resultado: pasta 'dist/' criada
ls -la dist/
```

### Passo 2: Upload da Build

```bash
# No seu COMPUTADOR LOCAL:

# Criar diretório no VPS
ssh clinic@SEU_IP_DO_VPS "mkdir -p /home/clinic/apps/frontend-dist"

# Copiar build para VPS
scp -r dist/* clinic@SEU_IP_DO_VPS:/home/clinic/apps/frontend-dist/

# Verificar (no VPS via SSH)
ls -la /home/clinic/apps/frontend-dist/
```

---

## 🌐 Configurar Nginx

### Instalar Nginx

```bash
# No VPS, como clinic (com sudo):
sudo apt install -y nginx

# Iniciar
sudo systemctl start nginx
sudo systemctl enable nginx

# Verificar
sudo systemctl status nginx
```

### Configurar Frontend

```bash
# Criar arquivo de configuração
sudo nano /etc/nginx/sites-available/clinic-web
```

**Colar esta configuração:**

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name seudominio.com.br www.seudominio.com.br;

    # Raiz do frontend
    root /home/clinic/apps/frontend-dist;
    index index.html;

    # Servir arquivos estáticos com cache
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # Roteamento SPA - redireciona tudo para index.html
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Proxy para API backend
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Limite de upload
    client_max_body_size 100M;

    # Security headers
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
```

**Salvar:**
```
Ctrl+O, Enter, Ctrl+X
```

### Habilitar Site

```bash
# Criar link simbólico
sudo ln -s /etc/nginx/sites-available/clinic-web /etc/nginx/sites-enabled/

# Desabilitar site padrão (opcional)
sudo rm /etc/nginx/sites-enabled/default

# Testar configuração
sudo nginx -t
# Deve mostrar: "syntax is ok"

# Recarregar Nginx
sudo systemctl reload nginx
```

### Configurar API Subdomain (Opcional)

Se quiser separar `/api` em domínio diferente:

```bash
# Criar configuração para API
sudo nano /etc/nginx/sites-available/clinic-api
```

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name api.seudominio.com.br;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    client_max_body_size 100M;
}
```

```bash
# Habilitar
sudo ln -s /etc/nginx/sites-available/clinic-api /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 🔗 Configurar Domínio

### ⚡ ALTERNATIVA: Usar Apenas IP (Sem Domínio)

**Vantagens:**
- ✅ Sem custo de domínio
- ✅ Sem esperar propagação DNS
- ✅ Muito mais rápido para começar
- ✅ Perfeito para testes/desenvolvimento

**Desvantagens:**
- ❌ URL fica: `http://SEU_IP:PORT`
- ❌ Sem SSL/HTTPS (a menos que use certificado auto-assinado)
- ❌ Menos profissional para clientes

#### Configuração Nginx com IP

```bash
# Editar configuração Nginx
sudo nano /etc/nginx/sites-available/clinic-web
```

```nginx
server {
    listen 80;
    listen [::]:80;
    # Deixar em branco ou aceitar qualquer servidor
    server_name _;

    # Raiz do frontend
    root /home/clinic/apps/frontend-dist;
    index index.html;

    # Cache de arquivos estáticos
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Roteamento SPA
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Proxy para API
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }

    client_max_body_size 100M;
}
```

#### Configurar .env do Backend para IP

```bash
nano /home/clinic/apps/clinica/backend/.env

# Mudar CORS_ORIGIN para:
CORS_ORIGIN="http://SEU_IP:80"

# Depois reiniciar:
pm2 restart clinic-api
```

#### Acessar a Aplicação

```
Frontend:  http://SEU_IP_DO_VPS
API:       http://SEU_IP_DO_VPS/api/...
```

**Exemplo:**
```
http://200.123.45.67        (Frontend)
http://200.123.45.67/api/   (API)
```

#### Se Quiser Usar Portas Diferentes

```bash
# Backend na porta 3000 (direto, sem Nginx)
# Frontend na porta 8080 via Nginx

sudo nano /etc/nginx/sites-available/clinic-web
```

```nginx
server {
    listen 8080;
    server_name _;

    root /home/clinic/apps/frontend-dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Proxy /api para backend na 3000
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

**Acessar:**
```
Frontend:  http://SEU_IP:8080
API:       http://SEU_IP:8080/api  (ou http://SEU_IP:3000)
```

---

### 1. Domínio Registrado Externamente

Se seu domínio está em outro registrador (GoDaddy, Namecheap, etc):

**No painel do registrador:**
1. Vá em **Gerenciar DNS**
2. Encontre **Nameservers**
3. Altere para os nameservers da Integratorhost:
   - `ns1.integratorhost.com`
   - `ns2.integratorhost.com`
   - `ns3.integratorhost.com`

> Pode levar 24-48h para propagar

### 2. Gerenciar DNS na Integratorhost

**No painel Integratorhost:**

1. Vá em **Serviços → Domínios** (ou **Gerenciar DNS**)
2. Selecione seu domínio
3. Clique em **Editar Zona DNS**
4. Adicione/Edite estes registros:

```
Tipo   Nome              Valor             TTL
A      @                 SEU_IP_DO_VPS     3600
A      www               SEU_IP_DO_VPS     3600
A      api               SEU_IP_DO_VPS     3600
CNAME  www               seudominio.com.br 3600
```

### 3. Testar Resolução DNS

```bash
# No seu COMPUTADOR LOCAL:

# Verificar se domínio está apontando
nslookup seudominio.com.br
nslookup api.seudominio.com.br

# Deve mostrar seu IP do VPS

# Testar acesso HTTP
curl http://seudominio.com.br
```

---

## 🔒 SSL/HTTPS com Let's Encrypt

### ⚡ Se Usar Apenas IP (Pule Esta Seção)

Se você está usando apenas IP (sem domínio), **pode pular SSL por enquanto** porque:
- Let's Encrypt requer domínio válido
- Certificados auto-assinados são complexos
- Para testes/desenvolvimento, HTTP é aceitável

**Se quiser HTTPS com IP no futuro:**
- Compre um domínio (R$ 20-50/ano)
- Configure domínio (próximas seções)
- Volte aqui para ativar SSL

---

### Instalar Certbot

```bash
# No VPS:
sudo apt install -y certbot python3-certbot-nginx

# Verificar instalação
certbot --version
```

### Gerar Certificados

```bash
# Gerar para seu domínio (escolha sua opção):

# Opção 1: Apenas domínio raiz
sudo certbot certonly --nginx -d seudominio.com.br

# Opção 2: Domínio raiz + subdomínios
sudo certbot certonly --nginx -d seudominio.com.br -d www.seudominio.com.br -d api.seudominio.com.br

# Certbot fará validação e criará certificados
```

**Se pedindo email:**
- Coloque um email real (para avisos de expiração)
- Aceite os termos
- Aceite compartilhar email (ou não)

**Resultado:**
```
Congratulations! Your certificate has been issued.
Certificate is saved at: /etc/letsencrypt/live/seudominio.com.br/
```

### Atualizar Nginx para HTTPS

```bash
# Editar configuração do frontend
sudo nano /etc/nginx/sites-available/clinic-web
```

**Substituir por:**

```nginx
# Redirecionar HTTP para HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name seudominio.com.br www.seudominio.com.br;
    return 301 https://$server_name$request_uri;
}

# HTTPS
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name seudominio.com.br www.seudominio.com.br;

    # Certificados SSL
    ssl_certificate /etc/letsencrypt/live/seudominio.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/seudominio.com.br/privkey.pem;

    # Configurações SSL
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Resto da configuração anterior...
    root /home/clinic/apps/frontend-dist;
    index index.html;

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    client_max_body_size 100M;

    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
```

**Se usar subdomínio api:**

```bash
sudo nano /etc/nginx/sites-available/clinic-api
```

```nginx
# Redirecionar HTTP
server {
    listen 80;
    server_name api.seudominio.com.br;
    return 301 https://$server_name$request_uri;
}

# HTTPS
server {
    listen 443 ssl http2;
    server_name api.seudominio.com.br;

    ssl_certificate /etc/letsencrypt/live/seudominio.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/seudominio.com.br/privkey.pem;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    client_max_body_size 100M;
}
```

### Recarregar Nginx

```bash
sudo nginx -t
sudo systemctl reload nginx
```

### Renovação Automática

```bash
# Testar renovação
sudo certbot renew --dry-run

# Habilitar renovação automática
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer

# Verificar status
sudo systemctl status certbot.timer
```

---

## 🚨 Troubleshooting

### "Connection refused" ao acessar site

```bash
# 1. Verificar se Nginx está rodando
sudo systemctl status nginx

# 2. Se não, iniciar:
sudo systemctl start nginx

# 3. Verificar se backend está rodando
pm2 status

# 4. Se não, iniciar:
pm2 start npm --name "clinic-api" -- start

# 5. Ver logs do backend
pm2 logs clinic-api --lines 50

# 6. Ver logs do Nginx
sudo tail -f /var/log/nginx/error.log
```

### "CORS Error" no frontend

**Problema:** Frontend consegue carregar mas API retorna erro CORS

```bash
# No VPS, editar .env do backend:
nano /home/clinic/apps/clinica/backend/.env

# Verificar CORS_ORIGIN está correto:
CORS_ORIGIN="https://seudominio.com.br,https://www.seudominio.com.br"

# Se mudar, reiniciar backend:
pm2 restart clinic-api

# Verificar logs:
pm2 logs clinic-api
```

### "502 Bad Gateway"

Significa Nginx não consegue conectar ao backend

```bash
# 1. Verificar se processo Node está rodando
pm2 status

# 2. Verificar porta 3000 está aberta
sudo netstat -tulpn | grep 3000
# Deve mostrar Node ouvindo em 127.0.0.1:3000

# 3. Se não, reiniciar
pm2 restart clinic-api

# 4. Conferir arquivo .env
cat /home/clinic/apps/clinica/backend/.env | grep PORT

# 5. Ver logs
pm2 logs clinic-api -n 50
```

### "Database connection error"

```bash
# 1. Verificar se banco está rodando
# PostgreSQL:
sudo systemctl status postgresql

# MySQL:
sudo systemctl status mariadb

# 2. Conferir DATABASE_URL em .env
cat /home/clinic/apps/clinica/backend/.env | grep DATABASE_URL

# 3. Testar conexão manual
# PostgreSQL:
psql -h localhost -U clinic_user -d clinic_saas
# Digite senha

# MySQL:
mysql -h localhost -u clinic_user -p clinic_saas
# Digite senha

# Se conectar = banco OK
\q ou EXIT;

# 4. Se não conseguir conectar, checar senha/usuário
# 5. Ver logs backend:
pm2 logs clinic-api
```

### "SSL certificate not valid"

```bash
# 1. Listar certificados
sudo certbot certificates

# 2. Renovar manualmente
sudo certbot renew --force-renewal

# 3. Recarregar Nginx
sudo systemctl reload nginx

# 4. Verificar em navegador que SSL está OK
# (URL deve ter cadeado verde)
```

### Disco cheio ou erro de espaço

```bash
# Ver espaço disponível
df -h

# Ver pasta que ocupa mais espaço
du -sh /home/clinic/apps/*

# Limpar logs PM2 (se necessário)
pm2 flush

# Limpar cache do sistema
sudo apt clean
sudo apt autoclean

# Ver espaço usado by node_modules
du -sh /home/clinic/apps/clinica/backend/node_modules
# Se muito grande, pode reinstalar (npm ci ao invés de npm install)
```

### Memória insuficiente

```bash
# Ver memória disponível
free -h

# Ver processo Node usando mais memória
ps aux | grep node

# Aumentar heap do Node (editar PM2)
pm2 start npm --name "clinic-api" --max-memory-restart 500M -- start

# Ou criar arquivo ecosystem.config.js para configuração permanente
```

---

## 📊 Otimizações

### 1. Compressão

```bash
sudo nano /etc/nginx/nginx.conf

# Encontrar a seção http { e adicionar:
gzip on;
gzip_vary on;
gzip_min_length 1000;
gzip_proxied any;
gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript application/json;

# Salvar e recarregar:
sudo nginx -t
sudo systemctl reload nginx
```

### 2. Backup Automático

```bash
# Criar script
nano ~/backup-clinic.sh
```

```bash
#!/bin/bash

BACKUP_DIR="/home/clinic/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Criar diretório se não existir
mkdir -p $BACKUP_DIR

# Backup PostgreSQL
PGPASSWORD='sua_senha_super_segura_123!' pg_dump -h localhost -U clinic_user clinic_saas | gzip > $BACKUP_DIR/clinic_saas_$DATE.sql.gz

# Backup arquivos importantes
tar -czf $BACKUP_DIR/clinic_apps_$DATE.tar.gz /home/clinic/apps/clinica/

echo "Backup realizado: $DATE"
```

```bash
# Tornar executável
chmod +x ~/backup-clinic.sh

# Agendar (executar diariamente às 2 da manhã)
crontab -e

# Adicionar linha:
0 2 * * * /home/clinic/backup-clinic.sh >> /home/clinic/backup.log 2>&1

# Salvar: Ctrl+O, Enter, Ctrl+X
```

### 3. Monitoramento com Uptime Robot

1. Vá em https://uptimerobot.com
2. Criar conta gratuita
3. Adicionar monitor HTTP
4. URL: `https://seudominio.com.br`
5. Intervalo: 5 minutos
6. Receber alertas por email

---

## ✅ Checklist Final - Com Domínio

- [ ] VPS contratada e ativa na Integratorhost
- [ ] SSH funcionando
- [ ] Usuário não-root criado
- [ ] Sistema atualizado
- [ ] Node.js v18 instalado
- [ ] PostgreSQL/MySQL instalado e funcionando
- [ ] Banco criado e usuário configurado
- [ ] Backend clonado/enviado para VPS
- [ ] .env backend configurado corretamente
- [ ] Prisma migrations rodadas
- [ ] PM2 instalado e backend iniciado
- [ ] Nginx instalado e configurado
- [ ] Frontend build criada e enviada para VPS
- [ ] Domínio apontando para IP do VPS
- [ ] SSL/HTTPS configurado com Let's Encrypt
- [ ] CORS configurado no backend
- [ ] Teste: `https://seudominio.com.br` carrega
- [ ] Teste: Login funcionando
- [ ] Teste: API respondendo em `/api/*`
- [ ] Backup automático configurado
- [ ] Monitoramento configurado

## ✅ Checklist Final - Apenas IP (Sem Domínio)

- [ ] VPS contratada e ativa na Integratorhost
- [ ] SSH funcionando
- [ ] Usuário não-root criado
- [ ] Sistema atualizado
- [ ] Node.js v18 instalado
- [ ] PostgreSQL/MySQL instalado e funcionando
- [ ] Banco criado e usuário configurado
- [ ] Backend clonado/enviado para VPS
- [ ] .env backend com CORS_ORIGIN="http://SEU_IP"
- [ ] Prisma migrations rodadas
- [ ] PM2 instalado e backend iniciado
- [ ] Nginx instalado e configurado para IP
- [ ] Frontend build criada e enviada para VPS
- [ ] Teste: `http://SEU_IP` carrega
- [ ] Teste: Login funcionando
- [ ] Teste: API respondendo
- [ ] Backup automático configurado

---

## 🎉 Pronto!

Sua aplicação está em produção!

```
Frontend:  https://seudominio.com.br
API:       https://seudominio.com.br/api
API Alt:   https://api.seudominio.com.br (se configurado)
```

---

## 📞 Suporte

**Problemas Integratorhost:**
- Painel: https://cliente.integratorhost.com
- Chat ao vivo no painel
- Email: suporte@integratorhost.com.br

**Comandos Úteis SSH:**

```bash
# Conectar
ssh clinic@SEU_IP

# Copiar arquivo local para VPS
scp arquivo.txt clinic@SEU_IP:/home/clinic/

# Copiar pasta VPS para local
scp -r clinic@SEU_IP:/home/clinic/apps ~/

# Ver arquivos no VPS
ssh clinic@SEU_IP "ls -la /home/clinic/apps"

# Executar comando no VPS
ssh clinic@SEU_IP "pm2 status"
```

**Status da aplicação:**

```bash
# SSH no VPS:
pm2 status           # Ver processos
pm2 logs clinic-api  # Ver logs tempo real
pm2 monit           # Monitor CPU/Memória

sudo systemctl status nginx
sudo systemctl status postgresql

# Testar conectividade
curl http://localhost:3000
curl https://seudominio.com.br
```

---

**Versão**: 1.0.0 - Janeiro 2026  
**Próxima atualização**: Abril 2026
