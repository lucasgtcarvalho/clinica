# 📡 Documentação da API REST

## Base URL
```
http://localhost:3000/api
```

## Autenticação
Todas as rotas (exceto login/register) requerem um token JWT no header:
```
Authorization: Bearer {token}
```

---

## 🔐 Autenticação

### Registrar Nova Clínica
```http
POST /auth/register
Content-Type: application/json

{
  "name": "João Silva",
  "email": "joao@clinic.com",
  "password": "senha123",
  "clinicName": "Clínica Beleza Premium"
}
```

**Resposta (201)**:
```json
{
  "message": "Clinic and user created successfully",
  "token": "eyJhbGc...",
  "user": {
    "id": "uuid",
    "email": "joao@clinic.com",
    "name": "João Silva",
    "role": "ADMIN"
  },
  "clinic": {
    "id": "uuid",
    "name": "Clínica Beleza Premium"
  }
}
```

### Fazer Login
```http
POST /auth/login
Content-Type: application/json

{
  "email": "joao@clinic.com",
  "password": "senha123"
}
```

**Resposta (200)**:
```json
{
  "message": "Login successful",
  "token": "eyJhbGc...",
  "user": {
    "id": "uuid",
    "email": "joao@clinic.com",
    "name": "João Silva",
    "role": "ADMIN",
    "clinicId": "uuid"
  },
  "clinic": {
    "id": "uuid",
    "name": "Clínica Beleza Premium"
  }
}
```

### Obter Dados do Usuário
```http
GET /auth/me
Authorization: Bearer {token}
```

**Resposta (200)**:
```json
{
  "user": {
    "id": "uuid",
    "email": "joao@clinic.com",
    "name": "João Silva",
    "role": "ADMIN",
    "phone": "11999999999",
    "canViewAgenda": true,
    "canViewClients": true,
    "canViewFinance": true,
    "canManageUsers": true
  },
  "clinic": {
    "id": "uuid",
    "name": "Clínica Beleza Premium",
    "primaryColor": "#6366f1",
    "secondaryColor": "#8b5cf6"
  }
}
```

---

## 📅 Agendamentos

### Listar Agendamentos
```http
GET /appointments?startDate=2024-01-01T00:00:00Z&endDate=2024-01-31T23:59:59Z&status=SCHEDULED
Authorization: Bearer {token}
```

**Query Params**:
- `startDate` (opcional): Data inicial (ISO 8601)
- `endDate` (opcional): Data final (ISO 8601)
- `clientId` (opcional): Filtrar por cliente
- `professionalId` (opcional): Filtrar por profissional
- `status` (opcional): SCHEDULED, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED, NO_SHOW

**Resposta (200)**: Array de agendamentos

### Criar Agendamento
```http
POST /appointments
Content-Type: application/json
Authorization: Bearer {token}

{
  "clientId": "uuid",
  "startTime": "2024-01-15T10:00:00Z",
  "endTime": "2024-01-15T11:00:00Z",
  "professionalId": "uuid",
  "services": [
    {
      "serviceId": "uuid",
      "duration": 60,
      "price": 150.00
    },
    {
      "serviceId": "uuid-2",
      "duration": 30,
      "price": 75.00
    }
  ],
  "notes": "Cliente pediu atenção especial"
}
```

**Resposta (201)**:
```json
{
  "message": "Appointment created successfully",
  "appointment": {
    "id": "uuid",
    "clientId": "uuid",
    "startTime": "2024-01-15T10:00:00Z",
    "endTime": "2024-01-15T11:00:00Z",
    "status": "SCHEDULED",
    "services": [
      {
        "id": "uuid",
        "serviceId": "uuid",
        "service": {
          "id": "uuid",
          "name": "Massagem Facial",
          "price": 150.00,
          "duration": 60
        },
        "duration": 60,
        "price": "150.00"
      }
    ]
  }
}
```

### Atualizar Agendamento
```http
PUT /appointments/{id}
Content-Type: application/json
Authorization: Bearer {token}

{
  "startTime": "2024-01-15T14:00:00Z",
  "endTime": "2024-01-15T15:00:00Z",
  "status": "CONFIRMED",
  "notes": "Novo comentário"
}
```

### Reagendar (Drag-and-Drop)
```http
PATCH /appointments/{id}/reschedule
Content-Type: application/json
Authorization: Bearer {token}

{
  "startTime": "2024-01-16T10:00:00Z",
  "endTime": "2024-01-16T11:00:00Z"
}
```

### Cancelar Agendamento
```http
DELETE /appointments/{id}
Authorization: Bearer {token}
```

---

## 👥 Clientes

### Listar Clientes
```http
GET /clients?search=joão
Authorization: Bearer {token}
```

**Query Params**:
- `search` (opcional): Buscar por nome, telefone, email ou CPF

**Resposta (200)**: Array de clientes

### Obter Cliente Completo
```http
GET /clients/{id}
Authorization: Bearer {token}
```

**Resposta (200)**:
```json
{
  "id": "uuid",
  "name": "João Silva",
  "email": "joao@email.com",
  "phone": "11999999999",
  "cpf": "123.456.789-00",
  "birthDate": "1990-05-15T00:00:00Z",
  "address": "Rua das Flores, 123",
  "city": "São Paulo",
  "state": "SP",
  "zipCode": "01234-567",
  "appointments": [
    {
      "id": "uuid",
      "startTime": "2024-01-10T10:00:00Z",
      "status": "COMPLETED",
      "services": []
    }
  ],
  "packages": [
    {
      "id": "uuid",
      "totalSessions": 10,
      "usedSessions": 3,
      "remainingSessions": 7
    }
  ],
  "photos": [],
  "transactions": [],
  "anamnesis": []
}
```

### Criar Cliente
```http
POST /clients
Content-Type: application/json
Authorization: Bearer {token}

{
  "name": "João Silva",
  "email": "joao@email.com",
  "phone": "11999999999",
  "cpf": "123.456.789-00",
  "birthDate": "1990-05-15",
  "address": "Rua das Flores, 123",
  "city": "São Paulo",
  "state": "SP",
  "zipCode": "01234-567"
}
```

### Atualizar Cliente
```http
PUT /clients/{id}
Content-Type: application/json
Authorization: Bearer {token}

{
  "name": "João Silva Atualizado",
  "email": "novo@email.com"
}
```

### Deletar Cliente
```http
DELETE /clients/{id}
Authorization: Bearer {token}
```

---

## 💰 Financeiro

### Listar Transações
```http
GET /finance?startDate=2024-01-01&endDate=2024-01-31&status=PAID
Authorization: Bearer {token}
```

**Query Params**:
- `startDate` (opcional): Data inicial
- `endDate` (opcional): Data final
- `status` (opcional): PENDING, PAID, PARTIALLY_PAID, OVERDUE, CANCELLED
- `clientId` (opcional): Filtrar por cliente
- `paymentMethod` (opcional): CASH, CREDIT_CARD, DEBIT_CARD, PIX, BANK_TRANSFER, CHECK, INSTALLMENT

### Criar Transação
```http
POST /finance
Content-Type: application/json
Authorization: Bearer {token}

{
  "clientId": "uuid",
  "description": "Tratamento de pele - 5 sessões",
  "amount": 500.00,
  "paymentMethod": "CREDIT_CARD",
  "installments": 3,
  "dueDate": "2024-02-15"
}
```

**Resposta (201)**:
```json
{
  "message": "Transaction created successfully",
  "transaction": {
    "id": "uuid",
    "clientId": "uuid",
    "description": "Tratamento de pele - 5 sessões",
    "amount": "500.00",
    "paymentMethod": "CREDIT_CARD",
    "status": "PARTIALLY_PAID",
    "installments": 3,
    "transactionDate": "2024-01-15T00:00:00Z",
    "dueDate": "2024-02-15",
    "installmentPlan": [
      {
        "id": "uuid",
        "installmentNumber": 1,
        "amount": "166.67",
        "dueDate": "2024-01-15",
        "status": "PENDING"
      },
      {
        "id": "uuid",
        "installmentNumber": 2,
        "amount": "166.67",
        "dueDate": "2024-02-15",
        "status": "PENDING"
      },
      {
        "id": "uuid",
        "installmentNumber": 3,
        "amount": "166.66",
        "dueDate": "2024-03-15",
        "status": "PENDING"
      }
    ]
  }
}
```

### Marcar Transação como Paga
```http
PATCH /finance/{id}/mark-paid
Authorization: Bearer {token}
```

### Relatório de Faturamento
```http
GET /finance/reports/general?startDate=2024-01-01&endDate=2024-01-31&groupBy=daily
Authorization: Bearer {token}
```

**Query Params**:
- `startDate` (opcional): Data inicial
- `endDate` (opcional): Data final
- `groupBy` (opcional): daily, weekly, monthly (padrão: daily)

**Resposta**:
```json
{
  "summary": {
    "totalAmount": 2500.00,
    "transactionCount": 8,
    "period": {
      "from": "2024-01-01",
      "to": "2024-01-31"
    }
  },
  "report": {
    "2024-01-15": {
      "total": 500.00,
      "count": 2,
      "byPaymentMethod": {
        "CASH": 200.00,
        "CREDIT_CARD": 300.00
      }
    }
  }
}
```

### Dashboard Financeiro
```http
GET /finance/dashboard
Authorization: Bearer {token}
```

**Resposta**:
```json
{
  "today": {
    "revenue": 750.00,
    "pending": 200.00,
    "pendingCount": 3
  },
  "lastThirtyDays": {
    "revenue": 5000.00
  },
  "paymentMethods": [
    {
      "paymentMethod": "CREDIT_CARD",
      "_sum": { "amount": 3000.00 },
      "_count": 5
    }
  ]
}
```

---

## 🏥 Serviços

### Listar Serviços
```http
GET /services/services
Authorization: Bearer {token}
```

### Criar Serviço
```http
POST /services/services
Content-Type: application/json
Authorization: Bearer {token}

{
  "name": "Massagem Facial",
  "description": "Massagem facial relaxante",
  "duration": 60,
  "price": 150.00
}
```

### Atualizar Serviço
```http
PUT /services/services/{id}
Content-Type: application/json
Authorization: Bearer {token}

{
  "name": "Massagem Facial Premium",
  "price": 180.00
}
```

### Deletar Serviço
```http
DELETE /services/services/{id}
Authorization: Bearer {token}
```

---

## 📦 Pacotes

### Listar Pacotes
```http
GET /services/packages
Authorization: Bearer {token}
```

### Criar Pacote
```http
POST /services/packages
Content-Type: application/json
Authorization: Bearer {token}

{
  "name": "Pacote Beleza Completa",
  "description": "5 sessões de tratamento facial",
  "totalPrice": 500.00,
  "sessionCount": 5,
  "services": ["uuid-service-1", "uuid-service-2"]
}
```

### Adicionar Pacote a Cliente
```http
POST /services/packages/add-to-client
Content-Type: application/json
Authorization: Bearer {token}

{
  "clientId": "uuid",
  "packageId": "uuid"
}
```

### Usar Sessão do Pacote
```http
PATCH /services/packages/use-session
Content-Type: application/json
Authorization: Bearer {token}

{
  "clientPackageId": "uuid",
  "sessions": 1
}
```

---

## 📋 Anamnese

### Listar Anamneses do Cliente
```http
GET /anamnesis/client/{clientId}
Authorization: Bearer {token}
```

### Obter Anamnese
```http
GET /anamnesis/{id}
Authorization: Bearer {token}
```

### Criar Anamnese
```http
POST /anamnesis
Content-Type: application/json
Authorization: Bearer {token}

{
  "clientId": "uuid",
  "appointmentId": "uuid",
  "answers": {
    "alergias": "Alérgica a benzoila",
    "sensibilidade": true,
    "procedimentos_anteriores": "Já fez laser facial"
  }
}
```

### Assinar Anamnese Digitalmente
```http
PATCH /anamnesis/{id}/sign
Content-Type: application/json
Authorization: Bearer {token}

{
  "signature": "data:image/png;base64,iVBORw0KGgo..."
}
```

**Resposta**:
```json
{
  "message": "Anamnesis signed successfully",
  "anamnesis": {
    "id": "uuid",
    "signature": "data:image/png;base64,...",
    "signedAt": "2024-01-15T10:30:00Z",
    "signedByIp": "192.168.1.1",
    "signedByUser": "uuid"
  }
}
```

---

## ❌ Códigos de Erro

| Status | Erro | Significado |
|--------|------|------------|
| 400 | Bad Request | Dados inválidos |
| 401 | Unauthorized | Token ausente ou inválido |
| 403 | Forbidden | Sem permissão |
| 404 | Not Found | Recurso não encontrado |
| 409 | Conflict | Conflito (ex: email duplicado) |
| 500 | Internal Server Error | Erro do servidor |

---

## 📌 Dicas

1. **Sempre incluir o token** no header Authorization
2. **Datas** devem estar em formato ISO 8601 (2024-01-15T10:00:00Z)
3. **Valores monetários** são números decimais com até 2 casas
4. **Soft delete**: Agendamentos deletados não aparecem nas listagens
5. **Multi-tenant**: Cada clínica vê apenas seus próprios dados

---

**Última atualização: Janeiro 2024**
