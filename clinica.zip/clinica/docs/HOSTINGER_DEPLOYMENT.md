# 🌐 Deploy no Hostinger - Guia Completo

**Data**: Janeiro 2026  
**Versão**: 1.0.0  
**Status**: ✅ Pronto para Produção

---

## 📋 Índice

1. [Escolher Plano Hostinger](#-escolher-plano-hostinger)
2. [Preparação Local](#-preparação-local)
3. [Setup Backend no Hostinger](#-setup-backend-no-hostinger)
4. [Setup Frontend no Hostinger](#-setup-frontend-no-hostinger)
5. [Configurar Domínio](#-configurar-domínio)
6. [SSL/HTTPS](#-ssl-https)
7. [Monitoramento](#-monitoramento)
8. [Troubleshooting](#-troubleshooting)

---

## 🎯 Escolher Plano Hostinger

### Opção 1: **VPS (Recomendado para Node.js)** ⭐

**Por que?** Controle total, Node.js nativo, melhor performance

**Plano Recomendado:**
- **Hostinger VPS 2** (básico para começar)
  - 2 vCPU cores
  - 4 GB RAM
  - 50 GB SSD
  - Tráfego ilimitado
  - R$ 39-49/mês

**Plano Crescimento:**
- **Hostinger VPS 3**
  - 4 vCPU cores
  - 8 GB RAM
  - 80 GB SSD
  - R$ 69-79/mês

**Upgrade Escala:**
- **Hostinger VPS 4**
  - 6 vCPU cores
  - 16 GB RAM
  - 160 GB SSD
  - R$ 139-149/mês

### Opção 2: Cloud Hosting (Alternativa)
- Mais caro mas com auto-scaling
- Ideal se esperado crescimento rápido
- ~R$ 79/mês (mínimo)

### ❌ Não Recomendado: Shared Hosting
- Não suporta Node.js nativo
- Limitações severas
- Não ideal para SaaS

---

## 💾 Preparação Local

### 1. Build do Frontend

```bash
cd /var/www/html/clinica/frontend

# Criar build otimizado
npm run build

# Resultado: pasta 'dist/' com arquivos estáticos otimizados
```

### 2. Preparar .env para Produção

**backend/.env (PRODUÇÃO)**:
```env
# Database
DATABASE_URL="postgresql://seu_user:senha@localhost:5432/clinic_saas"

# JWT
JWT_SECRET="gere-uma-chave-aleatoria-super-segura-32-caracteres"
JWT_EXPIRES_IN="7d"

# Server
PORT=3000
NODE_ENV="production"

# CORS
CORS_ORIGIN="https://seudominio.com.br"

# Email (opcional, para Phase 2)
SMTP_HOST="smtp.seu-email.com"
SMTP_PORT="587"
SMTP_USER="seu-email@exemplo.com"
SMTP_PASS="sua-senha-app"
```

**frontend/.env (PRODUÇÃO)**:
```env
VITE_API_URL="https://api.seudominio.com.br"
VITE_APP_NAME="Clinic SaaS"
```

### 3. Gerar JWT_SECRET Seguro

```bash
# No Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Copie o resultado para JWT_SECRET em .env
```

---

## 🖥️ Setup Backend no Hostinger

### Passo 1: Conectar via SSH

1. Acesse **Hostinger Dashboard** → **VPS** → **Gerenciar**
2. Copie as credenciais SSH (IP, usuário, senha)
3. Conecte localmente:

```bash
ssh root@SEU_IP_DO_VPS
# ou
ssh usuario@SEU_IP_DO_VPS
```

### Passo 2: Instalar Node.js e npm

```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js (v18 LTS)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verificar instalação
node --version  # v18.x.x
npm --version   # v9.x.x
```

### Passo 3: Instalar PostgreSQL

```bash
# Instalar PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Iniciar serviço
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Criar banco de dados
sudo -u postgres createdb clinic_saas

# Criar usuário
sudo -u postgres psql
# Dentro do psql:
CREATE USER clinic_user WITH PASSWORD 'sua_senha_super_segura_123!';
GRANT ALL PRIVILEGES ON DATABASE clinic_saas TO clinic_user;
\q
```

**Alternativa: MySQL**
```bash
sudo apt install -y mysql-server

# Durante instalação, configure senha root
# Depois:
sudo mysql -u root
CREATE DATABASE clinic_saas;
CREATE USER 'clinic_user'@'localhost' IDENTIFIED BY 'sua_senha_super_segura_123!';
GRANT ALL PRIVILEGES ON clinic_saas.* TO 'clinic_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### Passo 4: Instalar PM2 (Gerenciador de Processos)

```bash
# Instalar PM2 globalmente
sudo npm install -g pm2

# Verificar instalação
pm2 --version
```

### Passo 5: Clonar e Setup Backend

```bash
# Criar diretório da aplicação
mkdir -p /home/apps
cd /home/apps

# Clonar repositório (ou fazer upload via SCP)
git clone https://seu-repo-github.com/clinica.git
cd clinica/backend

# Instalar dependências
npm install --production

# Criar migrations do Prisma
npx prisma migrate deploy

# Gerar Prisma client
npx prisma generate
```

### Passo 6: Configurar .env no Servidor

```bash
# Criar arquivo .env
nano .env

# Cole o conteúdo:
DATABASE_URL="postgresql://clinic_user:sua_senha_super_segura_123!@localhost:5432/clinic_saas"
JWT_SECRET="gere-uma-chave-aleatoria-super-segura-32-caracteres"
JWT_EXPIRES_IN="7d"
PORT=3000
NODE_ENV="production"
CORS_ORIGIN="https://seudominio.com.br"

# Salvar: Ctrl+O, Enter, Ctrl+X
```

### Passo 7: Iniciar Backend com PM2

```bash
# Iniciar com PM2
pm2 start npm --name "clinic-backend" -- start

# Salvar configuração PM2
pm2 save

# Fazer PM2 iniciar no boot
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u root --hp /root

# Verificar status
pm2 status
pm2 logs clinic-backend
```

### Passo 8: Configurar Nginx como Reverse Proxy

```bash
# Instalar Nginx
sudo apt install -y nginx

# Criar configuração
sudo nano /etc/nginx/sites-available/clinic-api

# Colar configuração:
```

```nginx
server {
    listen 80;
    server_name api.seudominio.com.br;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Limite de upload
    client_max_body_size 100M;
}
```

```bash
# Habilitar site
sudo ln -s /etc/nginx/sites-available/clinic-api /etc/nginx/sites-enabled/

# Testar Nginx
sudo nginx -t

# Iniciar Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

---

## 🎨 Setup Frontend no Hostinger

### Opção A: Servir via Nginx (Recomendado)

```bash
# No seu VPS, criar diretório para frontend
mkdir -p /home/apps/clinica/frontend-dist

# No seu computador LOCAL:
cd /var/www/html/clinica/frontend
npm run build

# Fazer upload da pasta 'dist' para VPS via SCP:
scp -r dist/* root@SEU_IP:/home/apps/clinica/frontend-dist/
```

**Configurar Nginx:**

```bash
sudo nano /etc/nginx/sites-available/clinic-web
```

```nginx
server {
    listen 80;
    server_name seudominio.com.br www.seudominio.com.br;

    root /home/apps/clinica/frontend-dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    client_max_body_size 100M;
}
```

```bash
sudo ln -s /etc/nginx/sites-available/clinic-web /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Opção B: Deploy com Vercel/Netlify (Mais Fácil)

```bash
# Se preferir não gerenciar frontend no VPS:
# 1. Fazer push do código para GitHub
# 2. Conectar Vercel/Netlify ao repositório
# 3. Configurar VITE_API_URL para seu domínio
# 4. Deploy automático

# Vantagens:
# - CDN global
# - SSL automático
# - Deploy automático no push
# - Grátis até limite

# Desvantagem:
# - Custo se tráfego aumentar muito
```

---

## 🔗 Configurar Domínio

### 1. Comprar Domínio
- Hostinger vende domínios
- Ou use registrador externo (Namecheap, GoDaddy, etc)

### 2. Apontar Domínios para Hostinger

Se domínio em outro registrador:

```
Nameservers do Hostinger:
- ns1.hostinger.com
- ns2.hostinger.com
- ns3.hostinger.com
```

Se domínio na Hostinger:
- Ir em **Domínios** → **Gerenciar DNS**

### 3. Criar Registros DNS

```
Tipo    Nome                Host                Prioridade
A       seudominio.com      SEU_IP_DO_VPS       10
A       www                 SEU_IP_DO_VPS       10
A       api                 SEU_IP_DO_VPS       10
CNAME   www                 seudominio.com      -
```

### 4. Testar Resolução

```bash
nslookup seudominio.com
nslookup api.seudominio.com
```

---

## 🔒 SSL/HTTPS

### Opção A: Let's Encrypt com Certbot (Grátis) ⭐

```bash
# Instalar Certbot
sudo apt install -y certbot python3-certbot-nginx

# Gerar certificado
sudo certbot certonly --nginx -d seudominio.com.br -d www.seudominio.com.br -d api.seudominio.com.br

# Renovação automática
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

### Opção B: Certificado Hostinger

1. Ir em **SSL/TLS**
2. Comprar certificado (ou usar Let's Encrypt grátis)
3. Instalar automaticamente

### Atualizar Nginx para HTTPS

```bash
sudo nano /etc/nginx/sites-available/clinic-web
```

```nginx
# Adicionar antes de 'server {':
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name seudominio.com.br www.seudominio.com.br;

    ssl_certificate /etc/letsencrypt/live/seudominio.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/seudominio.com.br/privkey.pem;

    # Resto da config...
}

# Redirecionar HTTP para HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name seudominio.com.br www.seudominio.com.br;
    return 301 https://$server_name$request_uri;
}
```

```bash
sudo nginx -t
sudo systemctl reload nginx
```

---

## 📊 Monitoramento

### 1. Verificar Status Backend

```bash
# Via SSH no VPS:
pm2 status
pm2 logs clinic-backend --lines 100
pm2 monit
```

### 2. Verificar Banco de Dados

```bash
# PostgreSQL
sudo -u postgres psql -d clinic_saas

# MySQL
sudo mysql -u clinic_user -p clinic_saas
```

### 3. Verificar Nginx

```bash
sudo systemctl status nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### 4. Monitoramento Remoto

```bash
# Instalar Monit (opcional)
sudo apt install -y monit

# Ou usar ferramentas online:
# - Uptime Robot (grátis)
# - Pingdom
# - New Relic
```

### 5. Setup Alertas

**Uptime Robot (Recomendado)**:
1. Ir em https://uptimerobot.com
2. Fazer login
3. Adicionar monitor HTTP
4. URL: https://api.seudominio.com.br/health
5. Interval: 5 minutos
6. Receber alertas por email

---

## 🔧 Troubleshooting

### Problema: "Cannot connect to API"

```bash
# 1. Verificar se backend está rodando
pm2 status

# 2. Se não estiver:
pm2 start npm --name "clinic-backend" -- start

# 3. Verificar porta 3000
sudo netstat -tulpn | grep 3000

# 4. Verificar logs
pm2 logs clinic-backend
```

### Problema: "CORS Error"

**Solução**: Verificar CORS_ORIGIN em .env backend

```env
# backend/.env
CORS_ORIGIN="https://seudominio.com.br"
# Ou múltiplos:
CORS_ORIGIN="https://seudominio.com.br,https://www.seudominio.com.br"
```

Depois:
```bash
pm2 restart clinic-backend
```

### Problema: "Database connection error"

```bash
# 1. Verificar se PostgreSQL está rodando
sudo systemctl status postgresql

# 2. Verificar DATABASE_URL em .env
cat .env | grep DATABASE_URL

# 3. Testar conexão
sudo -u postgres psql -d clinic_saas -c "SELECT 1"
```

### Problema: "SSL certificate not valid"

```bash
# 1. Verificar certificado
sudo certbot certificates

# 2. Renovar manualmente
sudo certbot renew --force-renewal

# 3. Recarregar Nginx
sudo systemctl reload nginx
```

### Problema: "Arquivo muito grande no upload"

```bash
# Aumentar limite em Nginx:
sudo nano /etc/nginx/sites-available/clinic-api

# Encontrar e aumentar:
client_max_body_size 200M;  # ao invés de 100M

# Recarregar:
sudo systemctl reload nginx
```

### Problema: "Memória cheio"

```bash
# Verificar uso
free -h
df -h

# Limpar cache
sudo apt clean
sudo apt autoclean

# Aumentar swap (se necessário)
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

---

## 📈 Otimizações para Produção

### 1. Compressão Nginx

```nginx
gzip on;
gzip_min_length 1000;
gzip_types text/plain text/css text/javascript application/json;
```

### 2. Cache Headers

```nginx
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

### 3. Security Headers

```nginx
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
```

### 4. Backup Automático

```bash
# Script backup diário
sudo nano /usr/local/bin/backup-clinic.sh

#!/bin/bash
BACKUP_DIR="/home/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup banco PostgreSQL
sudo -u postgres pg_dump clinic_saas > $BACKUP_DIR/clinic_saas_$DATE.sql

# Compactar
gzip $BACKUP_DIR/clinic_saas_$DATE.sql

# Enviar para backup externo (opcional)
# scp $BACKUP_DIR/clinic_saas_$DATE.sql.gz usuario@backup-server:/backups/
```

```bash
# Agendador cron
sudo crontab -e

# Adicionar linha:
0 2 * * * /usr/local/bin/backup-clinic.sh  # Executar 2am todos os dias
```

---

## ✅ Checklist de Deploy

- [ ] VPS Hostinger contratado e ativo
- [ ] SSH funcionando
- [ ] Node.js v18+ instalado
- [ ] PostgreSQL/MySQL instalado e banco criado
- [ ] PM2 instalado e funcionando
- [ ] Backend clonado e dependências instaladas
- [ ] .env configurado com DATABASE_URL correto
- [ ] Prisma migrations executadas
- [ ] Backend iniciado com PM2
- [ ] Nginx instalado e configurado
- [ ] Frontend build criado e deployed
- [ ] Domínio apontando para IP do VPS
- [ ] SSL/HTTPS configurado e funcional
- [ ] CORS configurado no backend
- [ ] Testar login em https://seudominio.com.br
- [ ] Uptime Robot configurado para monitoramento
- [ ] Backup automático configurado

---

## 🎉 Pronto!

Sua aplicação agora está rodando em produção no Hostinger!

```bash
# Para acessar depois:
https://seudominio.com.br          # Frontend
https://api.seudominio.com.br/docs # API (se implementado)
```

---

## 📞 Suporte

**Problemas com Hostinger?**
- Chat ao vivo: Hostinger dashboard → Support
- Email: support@hostinger.com

**Problemas com aplicação?**
- Consulte os logs: `pm2 logs clinic-backend`
- Verifique .env está correto
- Verifique Database_URL

---

**Última Atualização**: Janeiro 2026  
**Próxima Review**: Abril 2026
