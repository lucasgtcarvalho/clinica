import React from 'react';
import { Calendar, Users, DollarSign, Settings, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import clsx from 'clsx';
import { useAuthStore } from '../store/auth';

export const BottomNavigation: React.FC = () => {
  const location = useLocation();
  const user = useAuthStore((s) => s.user);

  const allItems = [
    { icon: Home, label: 'Início', path: '/dashboard', permission: null as boolean | null },
    { icon: Calendar, label: 'Agenda', path: '/appointments', permission: user?.canViewAgenda ?? true },
    { icon: Users, label: 'Clientes', path: '/clients', permission: user?.canViewClients ?? true },
    { icon: DollarSign, label: 'Financeiro', path: '/finance', permission: user?.canViewFinance ?? false },
    { icon: Settings, label: 'Configurações', path: '/settings', permission: user?.canManageUsers ?? false },
  ];

  const items = allItems.filter((item) => item.permission !== false);

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-40">
      <div className="flex items-center justify-around h-20">
        {items.map(({ icon: Icon, label, path }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className={clsx(
                'flex flex-col items-center justify-center flex-1 h-full',
                'text-xs gap-1 transition-colors',
                isActive
                  ? 'text-indigo-600 bg-indigo-50'
                  : 'text-gray-600 hover:text-gray-900'
              )}
            >
              <Icon size={24} />
              <span className="font-medium">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};
