import React from 'react';
import clsx from 'clsx';

interface ToastProps {
  message: string;
  type?: 'success' | 'error' | 'info' | 'warning';
  visible: boolean;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({
  message,
  type = 'info',
  visible,
  onClose,
}) => {
  React.useEffect(() => {
    if (visible) {
      const timer = setTimeout(onClose, 3000);
      return () => clearTimeout(timer);
    }
  }, [visible, onClose]);

  if (!visible) return null;

  const bgColor = {
    success: 'bg-green-100 text-green-800',
    error: 'bg-red-100 text-red-800',
    info: 'bg-blue-100 text-blue-800',
    warning: 'bg-yellow-100 text-yellow-800',
  }[type];

  return (
    <div className={clsx(
      'fixed bottom-24 md:bottom-4 right-4 left-4 md:left-auto md:w-96',
      'p-4 rounded-lg shadow-lg',
      'animate-fade-in-up',
      bgColor
    )}>
      <p className="text-sm font-medium">{message}</p>
    </div>
  );
};
