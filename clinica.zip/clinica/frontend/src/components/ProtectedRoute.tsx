import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../store/auth';
import type { User } from '../types';

type PermissionKey = keyof Pick<User, 'canViewAgenda' | 'canViewClients' | 'canViewFinance' | 'canManageUsers'>;

interface ProtectedRouteProps {
  children: React.ReactNode;
  /** Se informado, redireciona para /dashboard quando o usuário não tiver a permissão. */
  permission?: PermissionKey;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, permission }) => {
  const { isAuthenticated, token, user, fetchMe } = useAuthStore();

  useEffect(() => {
    if (token && !isAuthenticated) {
      fetchMe();
    }
  }, [token, isAuthenticated, fetchMe]);

  if (!isAuthenticated && !token) {
    return <Navigate to="/login" />;
  }

  if (permission && user && !user[permission]) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};
