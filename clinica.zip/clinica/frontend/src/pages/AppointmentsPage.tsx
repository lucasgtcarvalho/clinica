import React, { useEffect, useState } from 'react';
import { Plus, ChevronLeft, ChevronRight } from 'lucide-react';
import { Header } from '../components/Header';
import { BottomNavigation } from '../components/BottomNavigation';
import { Loading } from '../components/Loading';
import { Toast } from '../components/Toast';
import api from '../services/api';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const AppointmentsPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [appointments, setAppointments] = useState([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'error' | 'success' }>({
    visible: false,
    message: '',
    type: 'success',
  });

  useEffect(() => {
    const loadAppointments = async () => {
      try {
        setIsLoading(true);
        const start = startOfMonth(currentDate);
        const end = endOfMonth(currentDate);
        
        const data = await api.getAppointments({
          startDate: start.toISOString(),
          endDate: end.toISOString(),
        });
        
        setAppointments(data);
      } catch (error: any) {
        setToast({
          visible: true,
          message: 'Erro ao carregar agendamentos',
          type: 'error',
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadAppointments();
  }, [currentDate]);

  const handlePreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const renderCalendar = () => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const days = eachDayOfInterval({ start, end });

    // Preencher dias do mês anterior
    const startDate = new Date(start);
    startDate.setDate(startDate.getDate() - start.getDay());

    const weeks: Date[][] = [];
    let currentWeek: Date[] = [];

    for (let i = 0; i < days.length + start.getDay(); i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      currentWeek.push(date);

      if (currentWeek.length === 7) {
        weeks.push([...currentWeek]);
        currentWeek = [];
      }
    }

    return weeks.map((week, weekIndex) => (
      <div key={weekIndex} className="grid grid-cols-7 gap-1 mb-1">
        {week.map((date, dayIndex) => {
          const dayAppointments = appointments.filter(
            (a: any) => format(new Date(a.startTime), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
          );

          return (
            <div
              key={dayIndex}
              className={`min-h-[80px] p-2 rounded border cursor-pointer transition-colors ${
                isSameMonth(date, currentDate)
                  ? 'bg-white hover:bg-gray-50'
                  : 'bg-gray-50'
              }`}
              onClick={() => {
                // Abrir modal de novo agendamento
              }}
            >
              <p className={`text-xs font-semibold mb-1 ${
                isSameMonth(date, currentDate) ? 'text-gray-900' : 'text-gray-400'
              }`}>
                {format(date, 'd')}
              </p>
              <div className="space-y-1">
                {dayAppointments.slice(0, 2).map((appointment: any) => (
                  <div
                    key={appointment.id}
                    className="text-xs bg-indigo-100 text-indigo-800 p-1 rounded truncate cursor-pointer hover:bg-indigo-200"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedAppointment(appointment);
                    }}
                  >
                    {format(new Date(appointment.startTime), 'HH:mm')} - {appointment.client.name}
                  </div>
                ))}
                {dayAppointments.length > 2 && (
                  <div className="text-xs text-gray-600 px-1">
                    +{dayAppointments.length - 2}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    ));
  };

  if (isLoading) {
    return <Loading fullScreen />;
  }

  return (
    <div className="pb-20">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Agenda</h1>
          </div>
          <a
            href="/appointments/new"
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg flex items-center gap-2 transition-colors"
          >
            <Plus size={20} />
            Novo Agendamento
          </a>
        </div>

        {/* Controles de visualização */}
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={handlePreviousMonth}
              className="p-2 hover:bg-gray-100 rounded transition-colors"
            >
              <ChevronLeft size={20} />
            </button>
            <h2 className="text-lg font-semibold text-gray-900">
              {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
            </h2>
            <button
              onClick={handleNextMonth}
              className="p-2 hover:bg-gray-100 rounded transition-colors"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Cabeçalho dos dias */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'].map((day) => (
              <div key={day} className="text-center text-sm font-semibold text-gray-600 py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendário */}
          {renderCalendar()}
        </div>

        {/* Detalhes do agendamento selecionado */}
        {selectedAppointment && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              Detalhes do Agendamento
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600">Cliente</p>
                <p className="font-semibold text-gray-900">{selectedAppointment.client.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Horário</p>
                <p className="font-semibold text-gray-900">
                  {format(new Date(selectedAppointment.startTime), 'HH:mm')} - {format(new Date(selectedAppointment.endTime), 'HH:mm')}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Status</p>
                <p className="font-semibold text-gray-900">{selectedAppointment.status}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Serviços</p>
                <p className="font-semibold text-gray-900">{selectedAppointment.services.length}</p>
              </div>
            </div>
          </div>
        )}
      </main>

      <Toast
        message={toast.message}
        type={toast.type}
        visible={toast.visible}
        onClose={() => setToast({ ...toast, visible: false })}
      />

      <BottomNavigation />
    </div>
  );
};
