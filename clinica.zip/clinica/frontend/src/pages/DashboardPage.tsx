import React, { useEffect, useState } from 'react';
import { Calendar, Users, TrendingUp, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Header } from '../components/Header';
import { BottomNavigation } from '../components/BottomNavigation';
import { Loading } from '../components/Loading';
import api from '../services/api';
import { useAuthStore } from '../store/auth';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const DashboardPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuthStore();
  const [stats, setStats] = useState({
    todayAppointments: 0,
    totalClients: 0,
    todayRevenue: 0,
    pendingAppointments: 0,
  });

  useEffect(() => {
    const loadStats = async () => {
      setError(null);
      try {
        const today = new Date().toISOString().split('T')[0];
        const [appointmentsRes, clientsRes, financeRes] = await Promise.allSettled([
          user?.canViewAgenda !== false
            ? api.getAppointments({ startDate: today, endDate: today })
            : Promise.resolve([]),
          user?.canViewClients !== false ? api.getClients() : Promise.resolve([]),
          user?.canViewFinance
            ? api.getFinanceDashboard()
            : Promise.resolve({ today: { revenue: 0 } }),
        ]);

        const appointments = appointmentsRes.status === 'fulfilled' ? appointmentsRes.value : [];
        const clients = clientsRes.status === 'fulfilled' ? clientsRes.value : [];
        const finance = financeRes.status === 'fulfilled' ? financeRes.value : { today: { revenue: 0 } };

        const appointmentList = Array.isArray(appointments) ? appointments : [];
        setStats({
          todayAppointments: appointmentList.filter((a: any) => a.status !== 'CANCELLED').length,
          totalClients: Array.isArray(clients) ? clients.length : 0,
          todayRevenue: (finance as any)?.today?.revenue ?? 0,
          pendingAppointments: appointmentList.filter((a: any) => a.status === 'SCHEDULED').length,
        });
      } catch (err) {
        console.error('Error loading stats:', err);
        setError('Não foi possível carregar os dados. Tente novamente.');
      } finally {
        setIsLoading(false);
      }
    };

    loadStats();
  }, [user?.canViewAgenda, user?.canViewClients, user?.canViewFinance]);

  if (isLoading) {
    return <Loading fullScreen />;
  }

  return (
    <div className="pb-20">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Bem-vindo ao Clinic SaaS
          </h1>
          <p className="text-gray-600">
            {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
          </p>
        </div>

        {/* Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Agendamentos Hoje</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats.todayAppointments}
                </p>
              </div>
              <Calendar className="w-12 h-12 text-indigo-600 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Total de Clientes</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats.totalClients}
                </p>
              </div>
              <Users className="w-12 h-12 text-blue-600 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Faturamento Hoje</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  R$ {stats.todayRevenue.toFixed(2)}
                </p>
              </div>
              <TrendingUp className="w-12 h-12 text-green-600 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Pendente de Confirmação</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats.pendingAppointments}
                </p>
              </div>
              <Clock className="w-12 h-12 text-yellow-600 opacity-20" />
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-sm">
            {error}
          </div>
        )}

        {/* Seção de Boas-vindas */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg shadow p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">Comece Agora!</h2>
          <p className="mb-6">
            Configure sua clínica, adicione clientes e comece a gerenciar seus agendamentos com facilidade.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {user?.canViewAgenda !== false && (
              <Link
                to="/appointments"
                className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all block"
              >
                <h3 className="font-semibold mb-2">Agenda</h3>
                <p className="text-sm text-opacity-90">Visualize e gerencie seus agendamentos</p>
              </Link>
            )}
            {user?.canViewClients !== false && (
              <Link
                to="/clients"
                className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all block"
              >
                <h3 className="font-semibold mb-2">Clientes</h3>
                <p className="text-sm text-opacity-90">Gerencie o cadastro de seus clientes</p>
              </Link>
            )}
            {user?.canViewFinance && (
              <Link
                to="/finance"
                className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all block"
              >
                <h3 className="font-semibold mb-2">Financeiro</h3>
                <p className="text-sm text-opacity-90">Acompanhe o faturamento e receitas</p>
              </Link>
            )}
          </div>
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
};
