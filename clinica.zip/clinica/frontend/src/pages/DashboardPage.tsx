import React, { useEffect, useState } from 'react';
import { Calendar, Users, TrendingUp, Clock } from 'lucide-react';
import { Header } from '../components/Header';
import { BottomNavigation } from '../components/BottomNavigation';
import { Loading } from '../components/Loading';
import api from '../services/api';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const DashboardPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    todayAppointments: 0,
    totalClients: 0,
    todayRevenue: 0,
    pendingAppointments: 0,
  });

  useEffect(() => {
    const loadStats = async () => {
      try {
        const [appointments, clients, finance] = await Promise.all([
          api.getAppointments({
            startDate: new Date().toISOString().split('T')[0],
            endDate: new Date().toISOString().split('T')[0],
          }),
          api.getClients(),
          api.getFinanceDashboard(),
        ]);

        setStats({
          todayAppointments: appointments.filter((a: any) => a.status !== 'CANCELLED').length,
          totalClients: clients.length,
          todayRevenue: finance.today?.revenue || 0,
          pendingAppointments: appointments.filter((a: any) => a.status === 'SCHEDULED').length,
        });
      } catch (error) {
        console.error('Error loading stats:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadStats();
  }, []);

  if (isLoading) {
    return <Loading fullScreen />;
  }

  return (
    <div className="pb-20">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Bem-vindo ao Clinic SaaS
          </h1>
          <p className="text-gray-600">
            {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
          </p>
        </div>

        {/* Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Agendamentos Hoje</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats.todayAppointments}
                </p>
              </div>
              <Calendar className="w-12 h-12 text-indigo-600 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Total de Clientes</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats.totalClients}
                </p>
              </div>
              <Users className="w-12 h-12 text-blue-600 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Faturamento Hoje</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  R$ {stats.todayRevenue.toFixed(2)}
                </p>
              </div>
              <TrendingUp className="w-12 h-12 text-green-600 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Pendente de Confirmação</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats.pendingAppointments}
                </p>
              </div>
              <Clock className="w-12 h-12 text-yellow-600 opacity-20" />
            </div>
          </div>
        </div>

        {/* Seção de Boas-vindas */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg shadow p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">Comece Agora!</h2>
          <p className="mb-6">
            Configure sua clínica, adicione clientes e comece a gerenciar seus agendamentos com facilidade.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <a
              href="/appointments"
              className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all"
            >
              <h3 className="font-semibold mb-2">Agenda</h3>
              <p className="text-sm text-opacity-90">Visualize e gerencie seus agendamentos</p>
            </a>
            <a
              href="/clients"
              className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all"
            >
              <h3 className="font-semibold mb-2">Clientes</h3>
              <p className="text-sm text-opacity-90">Gerencie o cadastro de seus clientes</p>
            </a>
            <a
              href="/finance"
              className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all"
            >
              <h3 className="font-semibold mb-2">Financeiro</h3>
              <p className="text-sm text-opacity-90">Acompanhe o faturamento e receitas</p>
            </a>
          </div>
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
};
