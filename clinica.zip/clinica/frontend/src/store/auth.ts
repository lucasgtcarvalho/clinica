import { create } from 'zustand';
import { User, Clinic } from '../types';
import api from '../services/api';

interface AuthStore {
  user: User | null;
  clinic: Clinic | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;

  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, clinicName: string) => Promise<void>;
  fetchMe: () => Promise<void>;
  logout: () => void;
  setToken: (token: string) => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  clinic: null,
  token: localStorage.getItem('token'),
  isLoading: false,
  isAuthenticated: !!localStorage.getItem('token'),

  login: async (email: string, password: string) => {
    set({ isLoading: true });
    try {
      const response = await api.login({ email, password });
      set({
        token: response.token,
        user: response.user,
        clinic: response.clinic,
        isAuthenticated: true,
      });
    } finally {
      set({ isLoading: false });
    }
  },

  register: async (name: string, email: string, password: string, clinicName: string) => {
    set({ isLoading: true });
    try {
      const response = await api.register({ name, email, password, clinicName });
      set({
        token: response.token,
        user: response.user,
        clinic: response.clinic,
        isAuthenticated: true,
      });
    } finally {
      set({ isLoading: false });
    }
  },

  fetchMe: async () => {
    try {
      const response = await api.getMe();
      set({
        user: response.user,
        clinic: response.clinic,
        isAuthenticated: true,
      });
    } catch (error) {
      set({
        user: null,
        clinic: null,
        token: null,
        isAuthenticated: false,
      });
      localStorage.removeItem('token');
    }
  },

  logout: () => {
    localStorage.removeItem('token');
    set({
      user: null,
      clinic: null,
      token: null,
      isAuthenticated: false,
    });
  },

  setToken: (token: string) => {
    localStorage.setItem('token', token);
    set({ token, isAuthenticated: true });
  },
}));
