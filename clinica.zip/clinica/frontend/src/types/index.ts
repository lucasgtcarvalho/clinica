export interface User {
  id: string;
  email: string;
  name: string;
  role: 'ADMIN' | 'PROFESSIONAL' | 'RECEPTION' | 'VIEWER';
  phone?: string;
  canViewAgenda: boolean;
  canViewClients: boolean;
  canViewFinance: boolean;
  canManageUsers: boolean;
}

export interface Clinic {
  id: string;
  name: string;
  slug: string;
  logo?: string;
  primaryColor: string;
  secondaryColor: string;
}

export interface Client {
  id: string;
  name: string;
  email?: string;
  phone: string;
  cpf?: string;
  birthDate?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  createdAt: string;
  updatedAt: string;
  appointments?: Appointment[];
  packages?: ClientPackage[];
  photos?: Photo[];
  transactions?: Transaction[];
  anamnesis?: Anamnesis[];
}

export interface Appointment {
  id: string;
  clientId: string;
  client?: Client;
  professionalId?: string;
  professional?: Professional;
  startTime: string;
  endTime: string;
  status: 'SCHEDULED' | 'CONFIRMED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';
  notes?: string;
  services: AppointmentService[];
  anamnesis?: Anamnesis;
  confirmedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AppointmentService {
  id: string;
  serviceId: string;
  service: Service;
  duration: number;
  price: number;
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  duration: number;
  price: number;
  createdAt: string;
  updatedAt: string;
}

export interface Package {
  id: string;
  name: string;
  description?: string;
  totalPrice: number;
  sessionCount: number;
  services: PackageService[];
  createdAt: string;
  updatedAt: string;
}

export interface PackageService {
  id: string;
  serviceId: string;
  service: Service;
}

export interface ClientPackage {
  id: string;
  clientId: string;
  packageId: string;
  package: Package;
  totalSessions: number;
  usedSessions: number;
  remainingSessions: number;
  expiryDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Transaction {
  id: string;
  clientId: string;
  client?: Client;
  description: string;
  amount: number;
  paymentMethod: 'CASH' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'PIX' | 'BANK_TRANSFER' | 'CHECK' | 'INSTALLMENT';
  status: 'PENDING' | 'PAID' | 'PARTIALLY_PAID' | 'OVERDUE' | 'CANCELLED';
  installments: number;
  transactionDate: string;
  dueDate?: string;
  installmentPlan?: Installment[];
  createdAt: string;
  updatedAt: string;
}

export interface Installment {
  id: string;
  transactionId: string;
  installmentNumber: number;
  amount: number;
  dueDate: string;
  paidAt?: string;
  status: string;
}

export interface Professional {
  id: string;
  userId: string;
  user?: User;
  specialization?: string;
  bio?: string;
  photo?: string;
  appointments?: Appointment[];
}

export interface Anamnesis {
  id: string;
  clientId: string;
  client?: Client;
  appointmentId?: string;
  appointment?: Appointment;
  answers: Record<string, any>;
  signature?: string;
  signedAt?: string;
  signedByIp?: string;
  signedByUser?: string;
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface Photo {
  id: string;
  clientId: string;
  client?: Client;
  appointmentId?: string;
  type: 'BEFORE' | 'AFTER';
  url: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}
