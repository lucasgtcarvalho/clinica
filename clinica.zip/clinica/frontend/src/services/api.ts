import axios, { AxiosInstance, AxiosError } from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

class ApiService {
  private api: AxiosInstance;

  constructor() {
    this.api = axios.create({
      baseURL: API_URL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Interceptor para adicionar token
    this.api.interceptors.request.use((config) => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });

    // Interceptor para tratar erros
    this.api.interceptors.response.use(
      (response) => response,
      (error: AxiosError) => {
        if (error.response?.status === 401) {
          localStorage.removeItem('token');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // Auth
  async register(data: { name: string; email: string; password: string; clinicName: string }) {
    const response = await this.api.post('/auth/register', data);
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
    }
    return response.data;
  }

  async login(data: { email: string; password: string }) {
    const response = await this.api.post('/auth/login', data);
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
    }
    return response.data;
  }

  async getMe() {
    const response = await this.api.get('/auth/me');
    return response.data;
  }

  // Appointments
  async getAppointments(params?: any) {
    const response = await this.api.get('/appointments', { params });
    return response.data;
  }

  async createAppointment(data: any) {
    const response = await this.api.post('/appointments', data);
    return response.data;
  }

  async updateAppointment(id: string, data: any) {
    const response = await this.api.put(`/appointments/${id}`, data);
    return response.data;
  }

  async rescheduleAppointment(id: string, data: any) {
    const response = await this.api.patch(`/appointments/${id}/reschedule`, data);
    return response.data;
  }

  async cancelAppointment(id: string) {
    const response = await this.api.delete(`/appointments/${id}`);
    return response.data;
  }

  // Clients
  async getClients(params?: any) {
    const response = await this.api.get('/clients', { params });
    return response.data;
  }

  async getClient(id: string) {
    const response = await this.api.get(`/clients/${id}`);
    return response.data;
  }

  async createClient(data: any) {
    const response = await this.api.post('/clients', data);
    return response.data;
  }

  async updateClient(id: string, data: any) {
    const response = await this.api.put(`/clients/${id}`, data);
    return response.data;
  }

  async deleteClient(id: string) {
    const response = await this.api.delete(`/clients/${id}`);
    return response.data;
  }

  // Finance
  async getTransactions(params?: any) {
    const response = await this.api.get('/finance', { params });
    return response.data;
  }

  async createTransaction(data: any) {
    const response = await this.api.post('/finance', data);
    return response.data;
  }

  async markTransactionAsPaid(id: string) {
    const response = await this.api.patch(`/finance/${id}/mark-paid`);
    return response.data;
  }

  async getFinanceReport(params?: any) {
    const response = await this.api.get('/finance/reports/general', { params });
    return response.data;
  }

  async getFinanceDashboard() {
    const response = await this.api.get('/finance/dashboard');
    return response.data;
  }

  // Services
  async getServices() {
    const response = await this.api.get('/services/services');
    return response.data;
  }

  async createService(data: any) {
    const response = await this.api.post('/services/services', data);
    return response.data;
  }

  async updateService(id: string, data: any) {
    const response = await this.api.put(`/services/services/${id}`, data);
    return response.data;
  }

  async deleteService(id: string) {
    const response = await this.api.delete(`/services/services/${id}`);
    return response.data;
  }

  // Packages
  async getPackages() {
    const response = await this.api.get('/services/packages');
    return response.data;
  }

  async createPackage(data: any) {
    const response = await this.api.post('/services/packages', data);
    return response.data;
  }

  async addPackageToClient(data: any) {
    const response = await this.api.post('/services/packages/add-to-client', data);
    return response.data;
  }

  async usePackageSession(data: any) {
    const response = await this.api.patch('/services/packages/use-session', data);
    return response.data;
  }

  // Anamnesis
  async getClientAnamnesis(clientId: string) {
    const response = await this.api.get(`/anamnesis/client/${clientId}`);
    return response.data;
  }

  async getAnamnesis(id: string) {
    const response = await this.api.get(`/anamnesis/${id}`);
    return response.data;
  }

  async createAnamnesis(data: any) {
    const response = await this.api.post('/anamnesis', data);
    return response.data;
  }

  async updateAnamnesis(id: string, data: any) {
    const response = await this.api.put(`/anamnesis/${id}`, data);
    return response.data;
  }

  async signAnamnesis(id: string, signature: string) {
    const response = await this.api.patch(`/anamnesis/${id}/sign`, { signature });
    return response.data;
  }
}

export default new ApiService();
