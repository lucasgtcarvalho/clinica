module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: 'var(--primary-color, #6366f1)',
        secondary: 'var(--secondary-color, #8b5cf6)',
      },
    },
  },
  plugins: [],
}
