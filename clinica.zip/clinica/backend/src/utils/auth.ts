import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

if (process.env.NODE_ENV === 'production' && (!JWT_SECRET || JWT_SECRET === 'your-secret-key')) {
  throw new Error('JWT_SECRET must be set in production. Configure the environment variable.');
}

export interface TokenPayload {
  userId: string;
  clinicId: string;
  email: string;
  role: string;
  canViewAgenda?: boolean;
  canViewClients?: boolean;
  canViewFinance?: boolean;
  canManageUsers?: boolean;
}

export const getJwtSecret = (): string => JWT_SECRET;

export const generateToken = (payload: TokenPayload): string => {
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });
};

export const verifyToken = (token: string): TokenPayload => {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as TokenPayload;
    return decoded;
  } catch (error) {
    throw new Error('Invalid or expired token');
  }
};

export const hashPassword = async (password: string): Promise<string> => {
  const bcrypt = require('bcryptjs');
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
};

export const comparePassword = async (password: string, hash: string): Promise<boolean> => {
  const bcrypt = require('bcryptjs');
  return bcrypt.compare(password, hash);
};
