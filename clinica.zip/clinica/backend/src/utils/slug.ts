import type { PrismaClient } from '@prisma/client';

/**
 * Normaliza texto para slug: minúsculo, sem acentos, apenas letras/números/hífen.
 */
function normalizeToSlug(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove acentos
    .replace(/[^a-z0-9\s-]/g, '') // remove caracteres especiais
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-') // múltiplos hífens -> um
    .replace(/^-|-$/g, '') || 'clinica';
}

/**
 * Gera um slug único para clínica. Se o slug já existir, adiciona sufixo numérico (-2, -3, ...).
 */
export async function generateUniqueClinicSlug(prisma: PrismaClient, name: string): Promise<string> {
  let baseSlug = normalizeToSlug(name);
  let slug = baseSlug;
  let counter = 1;

  while (true) {
    const existing = await prisma.clinic.findUnique({
      where: { slug },
    });
    if (!existing) return slug;
    counter += 1;
    slug = `${baseSlug}-${counter}`;
  }
}
