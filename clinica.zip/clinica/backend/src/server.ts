import express from 'express';
import cors from 'cors';
import 'dotenv/config';

// Middlewares
import { errorHandler, notFoundHandler } from './middlewares/error';
import { clinicMiddleware } from './middlewares/auth';

// Rotas
import authRoutes from './routes/auth';
import appointmentRoutes from './routes/appointments';
import clientRoutes from './routes/clients';
import financeRoutes from './routes/finance';
import serviceRoutes from './routes/services';
import anamnesisRoutes from './routes/anamnesis';

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares globais
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use(
  cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3001',
    credentials: true,
  }),
);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'Server is running' });
});

// Middleware de clínica
app.use(clinicMiddleware);

// Rotas
app.use('/api/auth', authRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/clients', clientRoutes);
app.use('/api/finance', financeRoutes);
app.use('/api/services', serviceRoutes);
app.use('/api/anamnesis', anamnesisRoutes);

// Middlewares de erro
app.use(notFoundHandler);
app.use(errorHandler);

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV}`);
});

export default app;
