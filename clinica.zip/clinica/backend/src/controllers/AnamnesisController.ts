import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { AppError } from '../utils/errors';
import { CreateAnamnesisDTO } from '../types/dtos';

const prisma = new PrismaClient();

export class AnamnesisController {
  async getByClient(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { clientId } = req.params;
      const clinicId = req.user.clinicId;

      const anamnesis = await prisma.anamnesis.findMany({
        where: {
          clientId,
          clinicId,
        },
        orderBy: { createdAt: 'desc' },
      });

      res.json(anamnesis);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch anamnesis' });
    }
  }

  async getById(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const clinicId = req.user.clinicId;

      const anamnesis = await prisma.anamnesis.findFirst({
        where: { id, clinicId },
        include: {
          client: {
            select: { id: true, name: true, phone: true, email: true },
          },
          appointment: {
            select: { id: true, startTime: true, status: true },
          },
        },
      });

      if (!anamnesis) {
        throw new AppError(404, 'Anamnesis not found');
      }

      res.json(anamnesis);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch anamnesis' });
    }
  }

  async create(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { clientId, appointmentId, answers }: CreateAnamnesisDTO = req.body;
      const clinicId = req.user.clinicId;

      if (!clientId || !answers) {
        throw new AppError(400, 'Client ID and answers are required');
      }

      // Verificar cliente
      const client = await prisma.client.findFirst({
        where: { id: clientId, clinicId },
      });

      if (!client) {
        throw new AppError(404, 'Client not found');
      }

      const anamnesis = await prisma.anamnesis.create({
        data: {
          clientId,
          clinicId,
          appointmentId,
          answers,
          version: 1,
        },
        include: {
          client: true,
          appointment: true,
        },
      });

      res.status(201).json({
        message: 'Anamnesis created successfully',
        anamnesis,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to create anamnesis' });
    }
  }

  async signAnamnesis(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const { signature } = req.body; // Base64 ou URL da imagem
      const clinicId = req.user.clinicId;

      if (!signature) {
        throw new AppError(400, 'Signature is required');
      }

      const anamnesis = await prisma.anamnesis.findFirst({
        where: { id, clinicId },
      });

      if (!anamnesis) {
        throw new AppError(404, 'Anamnesis not found');
      }

      // Registrar informações de assinatura
      const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '';
      const signedByUser = req.user.userId;

      const signed = await prisma.anamnesis.update({
        where: { id },
        data: {
          signature,
          signedAt: new Date(),
          signedByIp: Array.isArray(clientIp) ? clientIp[0] : String(clientIp),
          signedByUser,
        },
        include: {
          client: true,
          appointment: true,
        },
      });

      res.json({
        message: 'Anamnesis signed successfully',
        anamnesis: signed,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to sign anamnesis' });
    }
  }

  async update(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const { answers } = req.body;
      const clinicId = req.user.clinicId;

      if (!answers) {
        throw new AppError(400, 'Answers are required');
      }

      const existing = await prisma.anamnesis.findFirst({
        where: { id, clinicId },
      });

      if (!existing) {
        throw new AppError(404, 'Anamnesis not found');
      }

      // Incrementar versão
      const updated = await prisma.anamnesis.update({
        where: { id },
        data: {
          answers,
          version: existing.version + 1,
        },
        include: {
          client: true,
        },
      });

      res.json({
        message: 'Anamnesis updated successfully',
        anamnesis: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update anamnesis' });
    }
  }
}
