import { Request, Response } from 'express';
import { Decimal } from '@prisma/client/runtime/library';
import { AppError } from '../utils/errors';
import { CreateTransactionDTO } from '../types/dtos';
import { prisma } from '../lib/prisma';

export class FinanceController {
  // Listar transações com filtros
  async list(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { startDate, endDate, status, clientId, paymentMethod } = req.query;
      const clinicId = req.user.clinicId;

      const where: any = {
        clinicId,
        deletedAt: null,
      };

      if (startDate) {
        where.transactionDate = {
          gte: new Date(startDate as string),
        };
      }

      if (endDate) {
        if (where.transactionDate) {
          where.transactionDate.lte = new Date(endDate as string);
        } else {
          where.transactionDate = {
            lte: new Date(endDate as string),
          };
        }
      }

      if (status) {
        where.status = status;
      }

      if (clientId) {
        where.clientId = clientId;
      }

      if (paymentMethod) {
        where.paymentMethod = paymentMethod;
      }

      const transactions = await prisma.transaction.findMany({
        where,
        include: {
          client: {
            select: { id: true, name: true, phone: true },
          },
          installmentPlan: {
            orderBy: { installmentNumber: 'asc' },
          },
        },
        orderBy: { transactionDate: 'desc' },
      });

      res.json(transactions);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch transactions' });
    }
  }

  // Criar transação
  async create(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { clientId, appointmentId, description, amount, paymentMethod, installments = 1, dueDate }: CreateTransactionDTO = req.body;
      const clinicId = req.user.clinicId;

      if (!clientId || !description || !amount || !paymentMethod) {
        throw new AppError(400, 'Missing required fields');
      }

      // Verificar cliente
      const client = await prisma.client.findFirst({
        where: { id: clientId, clinicId },
      });

      if (!client) {
        throw new AppError(404, 'Client not found');
      }

      // Criar transação
      const transaction = await prisma.transaction.create({
        data: {
          clinicId,
          clientId,
          appointmentId,
          description,
          amount: new Decimal(amount),
          paymentMethod,
          status: paymentMethod === 'INSTALLMENT' ? 'PARTIALLY_PAID' : 'PENDING',
          installments,
          dueDate: dueDate ? new Date(dueDate) : null,
          transactionDate: new Date(),
          // Criar parcelas se for parcelado
          installmentPlan:
            installments > 1
              ? {
                  create: Array.from({ length: installments }, (_, i) => ({
                    installmentNumber: i + 1,
                    amount: new Decimal(amount / installments),
                    dueDate: new Date(new Date().setMonth(new Date().getMonth() + i)),
                    status: 'PENDING',
                  })),
                }
              : undefined,
        },
        include: {
          client: true,
          installmentPlan: true,
        },
      });

      res.status(201).json({
        message: 'Transaction created successfully',
        transaction,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to create transaction' });
    }
  }

  // Marcar transação como paga
  async markAsPaid(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const clinicId = req.user.clinicId;

      const transaction = await prisma.transaction.findFirst({
        where: { id, clinicId },
      });

      if (!transaction) {
        throw new AppError(404, 'Transaction not found');
      }

      const updated = await prisma.transaction.update({
        where: { id },
        data: {
          status: 'PAID',
          installmentPlan: {
            updateMany: {
              where: { transactionId: id },
              data: { status: 'PAID', paidAt: new Date() },
            },
          },
        },
        include: {
          installmentPlan: true,
          client: true,
        },
      });

      res.json({
        message: 'Transaction marked as paid',
        transaction: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update transaction' });
    }
  }

  // Relatório de faturamento
  async getReport(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { startDate, endDate, groupBy = 'daily' } = req.query;
      const clinicId = req.user.clinicId;

      const where: any = {
        clinicId,
        status: { in: ['PAID', 'PARTIALLY_PAID'] },
        deletedAt: null,
      };

      if (startDate) {
        where.transactionDate = {
          gte: new Date(startDate as string),
        };
      }

      if (endDate) {
        if (where.transactionDate) {
          where.transactionDate.lte = new Date(endDate as string);
        } else {
          where.transactionDate = {
            lte: new Date(endDate as string),
          };
        }
      }

      const transactions = await prisma.transaction.findMany({
        where,
        include: {
          client: true,
        },
      });

      // Agrupar por período
      const report: any = {};

      transactions.forEach((t) => {
        const date = new Date(t.transactionDate);
        let key = '';

        if (groupBy === 'daily') {
          key = date.toISOString().split('T')[0];
        } else if (groupBy === 'weekly') {
          const weekStart = new Date(date.setDate(date.getDate() - date.getDay()));
          key = weekStart.toISOString().split('T')[0];
        } else if (groupBy === 'monthly') {
          key = date.toISOString().slice(0, 7);
        }

        if (!report[key]) {
          report[key] = {
            total: 0,
            count: 0,
            byPaymentMethod: {},
            transactions: [],
          };
        }

        report[key].total += Number(t.amount);
        report[key].count += 1;
        report[key].transactions.push(t);

        const method = t.paymentMethod;
        if (!report[key].byPaymentMethod[method]) {
          report[key].byPaymentMethod[method] = 0;
        }
        report[key].byPaymentMethod[method] += Number(t.amount);
      });

      // Calcular total geral
      const totalAmount = transactions.reduce((sum, t) => sum + Number(t.amount), 0);

      res.json({
        summary: {
          totalAmount,
          transactionCount: transactions.length,
          period: {
            from: startDate || 'All time',
            to: endDate || 'Now',
          },
        },
        report,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to generate report' });
    }
  }

  // Dashboard financeiro
  async getDashboard(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const clinicId = req.user.clinicId;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      // Faturamento de hoje
      const todayRevenue = await prisma.transaction.aggregate({
        _sum: { amount: true },
        where: {
          clinicId,
          status: { in: ['PAID', 'PARTIALLY_PAID'] },
          transactionDate: { gte: today, lt: tomorrow },
        },
      });

      // Pendências de hoje
      const pendingToday = await prisma.transaction.aggregate({
        _sum: { amount: true },
        _count: true,
        where: {
          clinicId,
          status: 'PENDING',
          dueDate: { gte: today, lt: tomorrow },
        },
      });

      // Últimos 30 dias
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const monthRevenue = await prisma.transaction.aggregate({
        _sum: { amount: true },
        where: {
          clinicId,
          status: { in: ['PAID', 'PARTIALLY_PAID'] },
          transactionDate: { gte: thirtyDaysAgo },
        },
      });

      // Métodos de pagamento mais usados
      const paymentMethods = await prisma.transaction.groupBy({
        by: ['paymentMethod'],
        _sum: { amount: true },
        _count: true,
        where: {
          clinicId,
          status: { in: ['PAID', 'PARTIALLY_PAID'] },
        },
      });

      res.json({
        today: {
          revenue: todayRevenue._sum.amount || 0,
          pending: pendingToday._sum.amount || 0,
          pendingCount: pendingToday._count,
        },
        lastThirtyDays: {
          revenue: monthRevenue._sum.amount || 0,
        },
        paymentMethods,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch dashboard' });
    }
  }
}
