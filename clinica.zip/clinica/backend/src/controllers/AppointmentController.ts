import { Request, Response } from 'express';
import { AppError } from '../utils/errors';
import { CreateAppointmentDTO, UpdateAppointmentDTO } from '../types/dtos';
import { prisma } from '../lib/prisma';

export class AppointmentController {
  // Listar agendamentos com filtros
  async list(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { startDate, endDate, clientId, professionalId, status } = req.query;
      const clinicId = req.user.clinicId;

      const where: any = {
        clinicId,
        deletedAt: null,
      };

      if (startDate) {
        where.startTime = { gte: new Date(startDate as string) };
      }

      if (endDate) {
        where.endTime = { lte: new Date(endDate as string) };
      }

      if (clientId) {
        where.clientId = clientId;
      }

      if (professionalId) {
        where.professionalId = professionalId;
      }

      if (status) {
        where.status = status;
      }

      const appointments = await prisma.appointment.findMany({
        where,
        include: {
          client: {
            select: {
              id: true,
              name: true,
              phone: true,
              email: true,
            },
          },
          professional: {
            select: {
              id: true,
              user: { select: { name: true } },
            },
          },
          services: {
            include: { service: true },
          },
          anamnesis: true,
        },
        orderBy: { startTime: 'asc' },
      });

      res.json(appointments);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch appointments' });
    }
  }

  // Criar agendamento
  async create(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { clientId, startTime, endTime, professionalId, services, notes }: CreateAppointmentDTO = req.body;
      const clinicId = req.user.clinicId;

      // Validações
      if (!clientId || !startTime || !endTime || !services || services.length === 0) {
        throw new AppError(400, 'Missing required fields');
      }

      // Verificar conflito de horários
      const conflict = await prisma.appointment.findFirst({
        where: {
          clinicId,
          status: { not: 'CANCELLED' },
          OR: [
            {
              startTime: { lt: new Date(endTime) },
              endTime: { gt: new Date(startTime) },
            },
          ],
        },
      });

      if (conflict && !professionalId) {
        throw new AppError(409, 'Time slot already booked');
      }

      // Criar agendamento
      const appointment = await prisma.appointment.create({
        data: {
          clinicId,
          clientId,
          professionalId,
          startTime: new Date(startTime),
          endTime: new Date(endTime),
          notes,
          status: 'SCHEDULED',
          services: {
            create: services.map((service) => ({
              serviceId: service.serviceId,
              duration: service.duration,
              price: service.price,
            })),
          },
        },
        include: {
          client: {
            select: {
              id: true,
              name: true,
              phone: true,
              email: true,
            },
          },
          professional: {
            select: {
              id: true,
              user: { select: { name: true } },
            },
          },
          services: {
            include: { service: true },
          },
        },
      });

      res.status(201).json({
        message: 'Appointment created successfully',
        appointment,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to create appointment' });
    }
  }

  // Atualizar agendamento
  async update(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const { startTime, endTime, status, notes }: UpdateAppointmentDTO = req.body;
      const clinicId = req.user.clinicId;

      // Verificar se agendamento existe
      const appointment = await prisma.appointment.findFirst({
        where: { id, clinicId },
      });

      if (!appointment) {
        throw new AppError(404, 'Appointment not found');
      }

      // Atualizar
      const updated = await prisma.appointment.update({
        where: { id },
        data: {
          startTime: startTime ? new Date(startTime) : undefined,
          endTime: endTime ? new Date(endTime) : undefined,
          status,
          notes,
          confirmedAt: status === 'CONFIRMED' ? new Date() : undefined,
        },
        include: {
          client: {
            select: {
              id: true,
              name: true,
              phone: true,
              email: true,
            },
          },
          professional: {
            select: {
              id: true,
              user: { select: { name: true } },
            },
          },
          services: {
            include: { service: true },
          },
        },
      });

      res.json({
        message: 'Appointment updated successfully',
        appointment: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update appointment' });
    }
  }

  // Cancelar agendamento
  async cancel(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const clinicId = req.user.clinicId;

      const appointment = await prisma.appointment.findFirst({
        where: { id, clinicId },
      });

      if (!appointment) {
        throw new AppError(404, 'Appointment not found');
      }

      const updated = await prisma.appointment.update({
        where: { id },
        data: { status: 'CANCELLED', deletedAt: new Date() },
      });

      res.json({
        message: 'Appointment cancelled successfully',
        appointment: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to cancel appointment' });
    }
  }

  // Mover agendamento (drag-and-drop)
  async reschedule(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const { startTime, endTime } = req.body;
      const clinicId = req.user.clinicId;

      if (!startTime || !endTime) {
        throw new AppError(400, 'Start time and end time are required');
      }

      const appointment = await prisma.appointment.findFirst({
        where: { id, clinicId },
      });

      if (!appointment) {
        throw new AppError(404, 'Appointment not found');
      }

      // Verificar conflito (excluindo este agendamento)
      const conflict = await prisma.appointment.findFirst({
        where: {
          clinicId,
          id: { not: id },
          status: { not: 'CANCELLED' },
          OR: [
            {
              startTime: { lt: new Date(endTime) },
              endTime: { gt: new Date(startTime) },
            },
          ],
        },
      });

      if (conflict) {
        throw new AppError(409, 'Time slot already booked');
      }

      const updated = await prisma.appointment.update({
        where: { id },
        data: {
          startTime: new Date(startTime),
          endTime: new Date(endTime),
        },
        include: {
          client: true,
          services: { include: { service: true } },
        },
      });

      res.json({
        message: 'Appointment rescheduled successfully',
        appointment: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to reschedule appointment' });
    }
  }
}
