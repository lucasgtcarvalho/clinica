import { Request, Response } from 'express';
import { Decimal } from '@prisma/client/runtime/library';
import { AppError } from '../utils/errors';
import { CreateServiceDTO, CreatePackageDTO } from '../types/dtos';
import { prisma } from '../lib/prisma';

export class ServiceController {
  async list(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const clinicId = req.user.clinicId;

      const services = await prisma.service.findMany({
        where: {
          clinicId,
          deletedAt: null,
        },
        orderBy: { createdAt: 'asc' },
      });

      res.json(services);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch services' });
    }
  }

  async create(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { name, description, duration, price }: CreateServiceDTO = req.body;
      const clinicId = req.user.clinicId;

      if (!name || !duration || !price) {
        throw new AppError(400, 'Name, duration and price are required');
      }

      const service = await prisma.service.create({
        data: {
          clinicId,
          name,
          description,
          duration,
          price: new Decimal(price),
        },
      });

      res.status(201).json({
        message: 'Service created successfully',
        service,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to create service' });
    }
  }

  async update(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const { name, description, duration, price } = req.body;
      const clinicId = req.user.clinicId;

      const service = await prisma.service.findFirst({
        where: { id, clinicId },
      });

      if (!service) {
        throw new AppError(404, 'Service not found');
      }

      const updated = await prisma.service.update({
        where: { id },
        data: {
          name,
          description,
          duration,
          price: price ? new Decimal(price) : undefined,
        },
      });

      res.json({
        message: 'Service updated successfully',
        service: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update service' });
    }
  }

  async delete(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const clinicId = req.user.clinicId;

      const service = await prisma.service.findFirst({
        where: { id, clinicId },
      });

      if (!service) {
        throw new AppError(404, 'Service not found');
      }

      await prisma.service.update({
        where: { id },
        data: { deletedAt: new Date() },
      });

      res.json({
        message: 'Service deleted successfully',
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to delete service' });
    }
  }
}

export class PackageController {
  async list(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const clinicId = req.user.clinicId;

      const packages = await prisma.package.findMany({
        where: {
          clinicId,
          deletedAt: null,
        },
        include: {
          services: {
            include: { service: true },
          },
        },
        orderBy: { createdAt: 'asc' },
      });

      res.json(packages);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch packages' });
    }
  }

  async create(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { name, description, totalPrice, sessionCount, services }: CreatePackageDTO = req.body;
      const clinicId = req.user.clinicId;

      if (!name || !totalPrice || !sessionCount || !services || services.length === 0) {
        throw new AppError(400, 'Missing required fields');
      }

      const pkg = await prisma.package.create({
        data: {
          clinicId,
          name,
          description,
          totalPrice: new Decimal(totalPrice),
          sessionCount,
          services: {
            create: services.map((serviceId) => ({
              serviceId,
            })),
          },
        },
        include: {
          services: {
            include: { service: true },
          },
        },
      });

      res.status(201).json({
        message: 'Package created successfully',
        package: pkg,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to create package' });
    }
  }

  async addPackageToClient(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { clientId, packageId } = req.body;
      const clinicId = req.user.clinicId;

      if (!clientId || !packageId) {
        throw new AppError(400, 'Client ID and Package ID are required');
      }

      // Verificar cliente e pacote
      const [client, pkg] = await Promise.all([
        prisma.client.findFirst({
          where: { id: clientId, clinicId },
        }),
        prisma.package.findFirst({
          where: { id: packageId, clinicId },
        }),
      ]);

      if (!client) {
        throw new AppError(404, 'Client not found');
      }

      if (!pkg) {
        throw new AppError(404, 'Package not found');
      }

      // Verificar se cliente já tem este pacote
      const existing = await prisma.clientPackage.findFirst({
        where: { clientId, packageId },
      });

      if (existing) {
        throw new AppError(409, 'Client already has this package');
      }

      const clientPackage = await prisma.clientPackage.create({
        data: {
          clientId,
          packageId,
          totalSessions: pkg.sessionCount,
          usedSessions: 0,
          remainingSessions: pkg.sessionCount,
        },
        include: {
          package: {
            include: { services: { include: { service: true } } },
          },
        },
      });

      res.status(201).json({
        message: 'Package added to client successfully',
        clientPackage,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to add package' });
    }
  }

  async useSession(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { clientPackageId, sessions = 1 } = req.body;

      if (!clientPackageId) {
        throw new AppError(400, 'Client Package ID is required');
      }

      const clientPackage = await prisma.clientPackage.findUnique({
        where: { id: clientPackageId },
      });

      if (!clientPackage) {
        throw new AppError(404, 'Client package not found');
      }

      if (clientPackage.remainingSessions < sessions) {
        throw new AppError(400, 'Insufficient sessions available');
      }

      const updated = await prisma.clientPackage.update({
        where: { id: clientPackageId },
        data: {
          usedSessions: clientPackage.usedSessions + sessions,
          remainingSessions: clientPackage.remainingSessions - sessions,
        },
      });

      res.json({
        message: 'Sessions updated successfully',
        clientPackage: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update sessions' });
    }
  }
}
