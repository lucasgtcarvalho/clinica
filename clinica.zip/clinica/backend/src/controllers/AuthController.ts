import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { hashPassword, comparePassword, generateToken } from '../utils/auth';
import { AppError } from '../utils/errors';

const prisma = new PrismaClient();

export class AuthController {
  async register(req: Request, res: Response) {
    try {
      const { name, email, password, clinicName } = req.body;

      // Validações
      if (!name || !email || !password || !clinicName) {
        throw new AppError(400, 'Missing required fields');
      }

      // Verificar se email já existe
      const existingUser = await prisma.user.findUnique({
        where: { email },
      });

      if (existingUser) {
        throw new AppError(409, 'Email already registered');
      }

      // Criar clínica
      const clinic = await prisma.clinic.create({
        data: {
          name: clinicName,
          slug: clinicName.toLowerCase().replace(/\s+/g, '-'),
        },
      });

      // Hash da senha
      const hashedPassword = await hashPassword(password);

      // Criar usuário admin
      const user = await prisma.user.create({
        data: {
          name,
          email,
          password: hashedPassword,
          role: 'ADMIN',
          clinicId: clinic.id,
        },
      });

      // Gerar token
      const token = generateToken({
        userId: user.id,
        clinicId: clinic.id,
        email: user.email,
        role: user.role,
      });

      res.status(201).json({
        message: 'Clinic and user created successfully',
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        },
        clinic: {
          id: clinic.id,
          name: clinic.name,
        },
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Registration failed' });
    }
  }

  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        throw new AppError(400, 'Email and password are required');
      }

      // Buscar usuário
      const user = await prisma.user.findUnique({
        where: { email },
        include: {
          clinic: true,
        },
      });

      if (!user) {
        throw new AppError(401, 'Invalid credentials');
      }

      // Verificar senha
      const passwordMatch = await comparePassword(password, user.password);

      if (!passwordMatch) {
        throw new AppError(401, 'Invalid credentials');
      }

      // Gerar token
      const token = generateToken({
        userId: user.id,
        clinicId: user.clinicId,
        email: user.email,
        role: user.role,
      });

      res.json({
        message: 'Login successful',
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          clinicId: user.clinicId,
        },
        clinic: {
          id: user.clinic.id,
          name: user.clinic.name,
        },
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Login failed' });
    }
  }

  async me(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const user = await prisma.user.findUnique({
        where: { id: req.user.userId },
        include: {
          clinic: true,
          professional: true,
        },
      });

      if (!user) {
        throw new AppError(404, 'User not found');
      }

      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          phone: user.phone,
          canViewAgenda: user.canViewAgenda,
          canViewClients: user.canViewClients,
          canViewFinance: user.canViewFinance,
          canManageUsers: user.canManageUsers,
        },
        clinic: {
          id: user.clinic.id,
          name: user.clinic.name,
          primaryColor: user.clinic.primaryColor,
          secondaryColor: user.clinic.secondaryColor,
        },
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch user' });
    }
  }
}
