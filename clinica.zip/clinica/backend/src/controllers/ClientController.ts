import { Request, Response } from 'express';
import { AppError } from '../utils/errors';
import { CreateClientDTO } from '../types/dtos';
import { prisma } from '../lib/prisma';

export class ClientController {
  // Listar clientes
  async list(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { search } = req.query;
      const clinicId = req.user.clinicId;

      const where: any = {
        clinicId,
        deletedAt: null,
      };

      if (search) {
        where.OR = [
          { name: { contains: search as string, mode: 'insensitive' } },
          { phone: { contains: search as string, mode: 'insensitive' } },
          { email: { contains: search as string, mode: 'insensitive' } },
          { cpf: { contains: search as string, mode: 'insensitive' } },
        ];
      }

      const clients = await prisma.client.findMany({
        where,
        include: {
          packages: { include: { package: true } },
          appointments: { where: { deletedAt: null }, orderBy: { startTime: 'desc' } },
          _count: {
            select: { appointments: { where: { deletedAt: null } } },
          },
        },
        orderBy: { createdAt: 'desc' },
      });

      res.json(clients);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch clients' });
    }
  }

  // Obter cliente por ID
  async getById(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const clinicId = req.user.clinicId;

      const client = await prisma.client.findFirst({
        where: { id, clinicId, deletedAt: null },
        include: {
          appointments: {
            where: { deletedAt: null },
            include: {
              services: { include: { service: true } },
              anamnesis: true,
            },
            orderBy: { startTime: 'desc' },
          },
          packages: {
            include: { package: { include: { services: { include: { service: true } } } } },
          },
          anamnesis: {
            orderBy: { createdAt: 'desc' },
          },
          photos: {
            orderBy: { createdAt: 'desc' },
          },
          transactions: {
            where: { deletedAt: null },
            orderBy: { transactionDate: 'desc' },
          },
        },
      });

      if (!client) {
        throw new AppError(404, 'Client not found');
      }

      res.json(client);
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch client' });
    }
  }

  // Criar cliente
  async create(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { name, email, phone, cpf, birthDate, address, city, state, zipCode }: CreateClientDTO = req.body;
      const clinicId = req.user.clinicId;

      if (!name || !phone) {
        throw new AppError(400, 'Name and phone are required');
      }

      // Verificar duplicação
      const existing = await prisma.client.findFirst({
        where: {
          clinicId,
          phone,
        },
      });

      if (existing && !existing.deletedAt) {
        throw new AppError(409, 'Client with this phone already exists');
      }

      const client = await prisma.client.create({
        data: {
          clinicId,
          name,
          email,
          phone,
          cpf,
          birthDate: birthDate ? new Date(birthDate) : null,
          address,
          city,
          state,
          zipCode,
        },
      });

      res.status(201).json({
        message: 'Client created successfully',
        client,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to create client' });
    }
  }

  // Atualizar cliente
  async update(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const { name, email, phone, cpf, birthDate, address, city, state, zipCode } = req.body;
      const clinicId = req.user.clinicId;

      const client = await prisma.client.findFirst({
        where: { id, clinicId, deletedAt: null },
      });

      if (!client) {
        throw new AppError(404, 'Client not found');
      }

      const updated = await prisma.client.update({
        where: { id },
        data: {
          name,
          email,
          phone,
          cpf,
          birthDate: birthDate ? new Date(birthDate) : null,
          address,
          city,
          state,
          zipCode,
        },
      });

      res.json({
        message: 'Client updated successfully',
        client: updated,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update client' });
    }
  }

  // Deletar cliente (soft delete)
  async delete(req: Request, res: Response) {
    try {
      if (!req.user) {
        throw new AppError(401, 'Unauthorized');
      }

      const { id } = req.params;
      const clinicId = req.user.clinicId;

      const client = await prisma.client.findFirst({
        where: { id, clinicId },
      });

      if (!client) {
        throw new AppError(404, 'Client not found');
      }

      await prisma.client.update({
        where: { id },
        data: { deletedAt: new Date() },
      });

      res.json({
        message: 'Client deleted successfully',
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to delete client' });
    }
  }
}
