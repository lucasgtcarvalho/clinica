import { Request, Response, NextFunction } from 'express';
import { verifyToken } from '../utils/auth';
import { AppError } from '../utils/errors';

declare global {
  namespace Express {
    interface Request {
      user?: {
        userId: string;
        clinicId: string;
        email: string;
        role: string;
      };
    }
  }
}

export const authMiddleware = (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      throw new AppError(401, 'Missing authorization token');
    }

    const [, token] = authHeader.split(' ');

    if (!token) {
      throw new AppError(401, 'Invalid authorization format');
    }

    const decoded = verifyToken(token);
    req.user = decoded;

    next();
  } catch (error: any) {
    res.status(401).json({
      error: error.message || 'Unauthorized',
    });
  }
};

export const roleMiddleware = (allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'Insufficient permissions',
      });
    }

    next();
  };
};

export const clinicMiddleware = (req: Request, res: Response, next: NextFunction) => {
  // Adiciona clinicId às queries automaticamente
  if (req.user) {
    (req as any).clinicId = req.user.clinicId;
  }

  next();
};
