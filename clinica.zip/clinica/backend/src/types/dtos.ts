// tipos para requisição com autenticação
export interface AuthRequest {
  userId: string;
  clinicId: string;
  role: string;
  permissions?: {
    canViewAgenda: boolean;
    canViewClients: boolean;
    canViewFinance: boolean;
    canManageUsers: boolean;
  };
}

// DTOs para autenticação
export interface LoginDTO {
  email: string;
  password: string;
}

export interface RegisterDTO {
  name: string;
  email: string;
  password: string;
  clinicName: string;
}

// DTOs para Agendamento
export interface CreateAppointmentDTO {
  clientId: string;
  startTime: Date;
  endTime: Date;
  professionalId?: string;
  services: Array<{
    serviceId: string;
    duration: number;
    price: number;
  }>;
  notes?: string;
}

export interface UpdateAppointmentDTO {
  startTime?: Date;
  endTime?: Date;
  status?: 'SCHEDULED' | 'CONFIRMED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';
  notes?: string;
}

// DTOs para Cliente
export interface CreateClientDTO {
  name: string;
  email?: string;
  phone: string;
  cpf?: string;
  birthDate?: Date;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
}

// DTOs para Transação
export interface CreateTransactionDTO {
  clientId: string;
  appointmentId?: string;
  description: string;
  amount: number;
  paymentMethod: 'CASH' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'PIX' | 'BANK_TRANSFER' | 'CHECK' | 'INSTALLMENT';
  installments?: number;
  dueDate?: Date;
}

// DTOs para Anamnese
export interface CreateAnamnesisDTO {
  clientId: string;
  appointmentId?: string;
  answers: Record<string, any>;
  signature?: string;
}

// DTOs para Serviço
export interface CreateServiceDTO {
  name: string;
  description?: string;
  duration: number;
  price: number;
}

// DTOs para Pacote
export interface CreatePackageDTO {
  name: string;
  description?: string;
  totalPrice: number;
  sessionCount: number;
  services: string[]; // serviceIds
}
