import { Router } from 'express';
import { FinanceController } from '../controllers/FinanceController';
import { authMiddleware, permissionMiddleware } from '../middlewares/auth';

const router = Router();
const financeController = new FinanceController();

router.use(authMiddleware);
router.use(permissionMiddleware('canViewFinance'));

router.get('/', (req, res) => financeController.list(req, res));
router.post('/', (req, res) => financeController.create(req, res));
router.patch('/:id/mark-paid', (req, res) => financeController.markAsPaid(req, res));
router.get('/reports/general', (req, res) => financeController.getReport(req, res));
router.get('/dashboard', (req, res) => financeController.getDashboard(req, res));

export default router;
