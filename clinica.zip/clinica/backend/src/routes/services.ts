import { Router } from 'express';
import { ServiceController, PackageController } from '../controllers/ServiceController';
import { authMiddleware } from '../middlewares/auth';

const router = Router();
const serviceController = new ServiceController();
const packageController = new PackageController();

router.use(authMiddleware);

// Serviços
router.get('/services', (req, res) => serviceController.list(req, res));
router.post('/services', (req, res) => serviceController.create(req, res));
router.put('/services/:id', (req, res) => serviceController.update(req, res));
router.delete('/services/:id', (req, res) => serviceController.delete(req, res));

// Pacotes
router.get('/packages', (req, res) => packageController.list(req, res));
router.post('/packages', (req, res) => packageController.create(req, res));
router.post('/packages/add-to-client', (req, res) => packageController.addPackageToClient(req, res));
router.patch('/packages/use-session', (req, res) => packageController.useSession(req, res));

export default router;
