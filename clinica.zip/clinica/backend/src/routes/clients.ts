import { Router } from 'express';
import { ClientController } from '../controllers/ClientController';
import { authMiddleware, permissionMiddleware } from '../middlewares/auth';

const router = Router();
const clientController = new ClientController();

router.use(authMiddleware);
router.use(permissionMiddleware('canViewClients'));

router.get('/', (req, res) => clientController.list(req, res));
router.post('/', (req, res) => clientController.create(req, res));
router.get('/:id', (req, res) => clientController.getById(req, res));
router.put('/:id', (req, res) => clientController.update(req, res));
router.delete('/:id', (req, res) => clientController.delete(req, res));

export default router;
