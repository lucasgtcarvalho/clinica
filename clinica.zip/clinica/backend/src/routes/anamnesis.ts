import { Router } from 'express';
import { AnamnesisController } from '../controllers/AnamnesisController';
import { authMiddleware } from '../middlewares/auth';

const router = Router();
const anamnesisController = new AnamnesisController();

router.use(authMiddleware);

router.get('/client/:clientId', (req, res) => anamnesisController.getByClient(req, res));
router.get('/:id', (req, res) => anamnesisController.getById(req, res));
router.post('/', (req, res) => anamnesisController.create(req, res));
router.put('/:id', (req, res) => anamnesisController.update(req, res));
router.patch('/:id/sign', (req, res) => anamnesisController.signAnamnesis(req, res));

export default router;
