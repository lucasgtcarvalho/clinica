import { Router } from 'express';
import { AppointmentController } from '../controllers/AppointmentController';
import { authMiddleware } from '../middlewares/auth';

const router = Router();
const appointmentController = new AppointmentController();

router.use(authMiddleware);

router.get('/', (req, res) => appointmentController.list(req, res));
router.post('/', (req, res) => appointmentController.create(req, res));
router.put('/:id', (req, res) => appointmentController.update(req, res));
router.patch('/:id/reschedule', (req, res) => appointmentController.reschedule(req, res));
router.delete('/:id', (req, res) => appointmentController.cancel(req, res));

export default router;
